<?php
/* Silence is golden */
?>