<?php

namespace andreskrey\Readability\Nodes\DOM;

use andreskrey\Readability\Nodes\NodeTrait;

class DOMNotation extends \DOMNotation
{
    use NodeTrait;
}
