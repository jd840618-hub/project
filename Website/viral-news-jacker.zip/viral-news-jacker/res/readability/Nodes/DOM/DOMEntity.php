<?php

namespace andreskrey\Readability\Nodes\DOM;

use andreskrey\Readability\Nodes\NodeTrait;

class DOMEntity extends \DOMEntity
{
    use NodeTrait;
}
