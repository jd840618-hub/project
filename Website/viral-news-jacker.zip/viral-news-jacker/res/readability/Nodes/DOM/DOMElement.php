<?php

namespace andreskrey\Readability\Nodes\DOM;

use andreskrey\Readability\Nodes\NodeTrait;

class DOMElement extends \DOMElement
{
    use NodeTrait;
}
