<?php

namespace andreskrey\Readability\Nodes\DOM;

use andreskrey\Readability\Nodes\NodeTrait;

class DOMEntityReference extends \DOMEntityReference
{
    use NodeTrait;
}
