<?php

namespace andreskrey\Readability\Nodes\DOM;

use andreskrey\Readability\Nodes\NodeTrait;

class DOMDocumentType extends \DOMDocumentType
{
    use NodeTrait;
}
