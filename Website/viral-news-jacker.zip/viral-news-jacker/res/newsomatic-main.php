<?php
   function newszoo_admin_settings()
   {
       $language_names = array(
           esc_html__("Disabled"),
           esc_html__("Afrikaans (Google Translate)"),
           esc_html__("Albanian (Google Translate)"),
           esc_html__("Arabic (Google Translate)"),
           esc_html__("Amharic (Google Translate)"),
           esc_html__("Armenian (Google Translate)"),
           esc_html__("Belarusian (Google Translate)"),
           esc_html__("Bulgarian (Google Translate)"),
           esc_html__("Catalan (Google Translate)"),
           esc_html__("Chinese Simplified (Google Translate)"),
           esc_html__("Croatian (Google Translate)"),
           esc_html__("Czech (Google Translate)"),
           esc_html__("Danish (Google Translate)"),
           esc_html__("Dutch (Google Translate)"),
           esc_html__("English (Google Translate)"),
           esc_html__("Estonian (Google Translate)"),
           esc_html__("Filipino (Google Translate)"),
           esc_html__("Finnish (Google Translate)"),
           esc_html__("French (Google Translate)"),
           esc_html__("Galician (Google Translate)"),
           esc_html__("German (Google Translate)"),
           esc_html__("Greek (Google Translate)"),
           esc_html__("Hebrew (Google Translate)"),
           esc_html__("Hindi (Google Translate)"),
           esc_html__("Hungarian (Google Translate)"),
           esc_html__("Icelandic (Google Translate)"),
           esc_html__("Indonesian (Google Translate)"),
           esc_html__("Irish (Google Translate)"),
           esc_html__("Italian (Google Translate)"),
           esc_html__("Japanese (Google Translate)"),
           esc_html__("Korean (Google Translate)"),
           esc_html__("Latvian (Google Translate)"),
           esc_html__("Lithuanian (Google Translate)"),
           esc_html__("Norwegian (Google Translate)"),
           esc_html__("Macedonian (Google Translate)"),
           esc_html__("Malay (Google Translate)"),
           esc_html__("Maltese (Google Translate)"),
           esc_html__("Persian (Google Translate)"),
           esc_html__("Polish (Google Translate)"),
           esc_html__("Portuguese (Google Translate)"),
           esc_html__("Romanian (Google Translate)"),
           esc_html__("Russian (Google Translate)"),
           esc_html__("Serbian (Google Translate)"),
           esc_html__("Slovak (Google Translate)"),
           esc_html__("Slovenian (Google Translate)"),
           esc_html__("Spanish (Google Translate)"),
           esc_html__("Swahili (Google Translate)"),
           esc_html__("Swedish (Google Translate)"),
           esc_html__("Thai (Google Translate)"),
           esc_html__("Turkish (Google Translate)"),
           esc_html__("Ukrainian (Google Translate)"),
           esc_html__("Vietnamese (Google Translate)"),
           esc_html__("Welsh (Google Translate)"),
           esc_html__("Yiddish (Google Translate)"),
           esc_html__("Tamil (Google Translate)"),
           esc_html__("Azerbaijani (Google Translate)"),
           esc_html__("Kannada (Google Translate)"),
           esc_html__("Basque (Google Translate)"),
           esc_html__("Bengali (Google Translate)"),
           esc_html__("Latin (Google Translate)"),
           esc_html__("Chinese Traditional (Google Translate)"),
           esc_html__("Esperanto (Google Translate)"),
           esc_html__("Georgian (Google Translate)"),
           esc_html__("Telugu (Google Translate)"),
           esc_html__("Gujarati (Google Translate)"),
           esc_html__("Haitian Creole (Google Translate)"),
           esc_html__("Urdu (Google Translate)"),
           esc_html__("Burmese (Google Translate)"),
           esc_html__("Bosnian (Google Translate)"),
           esc_html__("Cebuano (Google Translate)"),
           esc_html__("Chichewa (Google Translate)"),
           esc_html__("Corsican (Google Translate)"),
           esc_html__("Frisian (Google Translate)"),
           esc_html__("Scottish Gaelic (Google Translate)"),
           esc_html__("Hausa (Google Translate)"),
           esc_html__("Hawaian (Google Translate)"),
           esc_html__("Hmong (Google Translate)"),
           esc_html__("Igbo (Google Translate)"),
           esc_html__("Javanese (Google Translate)"),
           esc_html__("Kazakh (Google Translate)"),
           esc_html__("Khmer (Google Translate)"),
           esc_html__("Kurdish (Google Translate)"),
           esc_html__("Kyrgyz (Google Translate)"),
           esc_html__("Lao (Google Translate)"),
           esc_html__("Luxembourgish (Google Translate)"),
           esc_html__("Malagasy (Google Translate)"),
           esc_html__("Malayalam (Google Translate)"),
           esc_html__("Maori (Google Translate)"),
           esc_html__("Marathi (Google Translate)"),
           esc_html__("Mongolian (Google Translate)"),
           esc_html__("Nepali (Google Translate)"),
           esc_html__("Pashto (Google Translate)"),
           esc_html__("Punjabi (Google Translate)"),
           esc_html__("Samoan (Google Translate)"),
           esc_html__("Sesotho (Google Translate)"),
           esc_html__("Shona (Google Translate)"),
           esc_html__("Sindhi (Google Translate)"),
           esc_html__("Sinhala (Google Translate)"),
           esc_html__("Somali (Google Translate)"),
           esc_html__("Sundanese (Google Translate)"),
           esc_html__("Swahili (Google Translate)"),
           esc_html__("Tajik (Google Translate)"),
           esc_html__("Uzbek (Google Translate)"),
           esc_html__("Xhosa (Google Translate)"),
           esc_html__("Yoruba (Google Translate)"),
           esc_html__("Zulu (Google Translate)")
       );
       $language_codes = array(
           "disabled",
           "af",
           "sq",
           "ar",
           "am",
           "hy",
           "be",
           "bg",
           "ca",
           "zh-CN",
           "hr",
           "cs",
           "da",
           "nl",
           "en",
           "et",
           "tl",
           "fi",
           "fr",
           "gl",
           "de",
           "el",
           "iw",
           "hi",
           "hu",
           "is",
           "id",
           "ga",
           "it",
           "ja",
           "ko",
           "lv",
           "lt",
           "no",
           "mk",
           "ms",
           "mt",
           "fa",
           "pl",
           "pt",
           "ro",
           "ru",
           "sr",
           "sk",
           "sl",
           "es",
           "sw",
           "sv",   
           "th",
           "tr",
           "uk",
           "vi",
           "cy",
           "yi",
           "ta",
           "az",
           "kn",
           "eu",
           "bn",
           "la",
           "zh-TW",
           "eo",
           "ka",
           "te",
           "gu",
           "ht",
           "ur",
           "my",
           "bs",
           "ceb",
           "ny",
           "co",
           "fy",
           "gd",
           "ha",
           "haw",
           "hmn",
           "ig",
           "jw",
           "kk",
           "km",
           "ku",
           "ky",
           "lo",
           "lb",
           "mg",
           "ml",
           "mi",
           "mr",
           "mn",
           "ne",
           "ps",
           "pa",
           "sm",
           "st",
           "sn",
           "sd",
           "si",
           "so",
           "su",
           "sw",
           "tg",
           "uz",
           "xh",
           "yo",
           "zu"
       );
       $language_names_deepl = array(
           "English (Deepl)",
           "German (Deepl)",
           "French (Deepl)",
           "Spanish (Deepl)",
           "Italian (Deepl)",
           "Dutch (Deepl)",
           "Polish (Deepl)",
           "Russian (Deepl)",
           "Portuguese (Deepl)"
       );
       $language_codes_deepl = array(
           "EN-",
           "DE-",
           "FR-",
           "ES-",
           "IT-",
           "NL-",
           "PL-",
           "RU-",
           "PT-"
       );
   ?>
<div class="wrap gs_popuptype_holder seo_pops">
   <div>
      <form id="myForm" method="post" action="<?php if(is_multisite() && is_network_admin()){echo '../options.php';}else{echo 'options.php';}?>">
         <div class="cr_autocomplete">
            <input type="password" id="PreventChromeAutocomplete" 
               name="PreventChromeAutocomplete" autocomplete="address-level4" />
         </div>
         <?php
            settings_fields('newsomatic_option_group');
            do_settings_sections('newsomatic_option_group');
            $newsomatic_Main_Settings = get_option('newsomatic_Main_Settings', false);
            if (isset($newsomatic_Main_Settings['newsomatic_enabled'])) {
                $newsomatic_enabled = $newsomatic_Main_Settings['newsomatic_enabled'];
            } else {
                $newsomatic_enabled = '';
            }
            if (isset($newsomatic_Main_Settings['enable_metabox'])) {
                $enable_metabox = $newsomatic_Main_Settings['enable_metabox'];
            } else {
                $enable_metabox = '';
            }
            if (isset($newsomatic_Main_Settings['sentence_list'])) {
                $sentence_list = $newsomatic_Main_Settings['sentence_list'];
            } else {
                $sentence_list = '';
            }
            if (isset($newsomatic_Main_Settings['sentence_list2'])) {
                $sentence_list2 = $newsomatic_Main_Settings['sentence_list2'];
            } else {
                $sentence_list2 = '';
            }
            if (isset($newsomatic_Main_Settings['user_agent'])) {
                $user_agent = $newsomatic_Main_Settings['user_agent'];
            } else {
                $user_agent = '';
            }
            if (isset($newsomatic_Main_Settings['variable_list'])) {
                $variable_list = $newsomatic_Main_Settings['variable_list'];
            } else {
                $variable_list = '';
            }
            if (isset($newsomatic_Main_Settings['enable_detailed_logging'])) {
                $enable_detailed_logging = $newsomatic_Main_Settings['enable_detailed_logging'];
            } else {
                $enable_detailed_logging = '';
            }
            if (isset($newsomatic_Main_Settings['enable_logging'])) {
                $enable_logging = $newsomatic_Main_Settings['enable_logging'];
            } else {
                $enable_logging = '';
            }
            if (isset($newsomatic_Main_Settings['auto_clear_logs'])) {
                $auto_clear_logs = $newsomatic_Main_Settings['auto_clear_logs'];
            } else {
                $auto_clear_logs = '';
            }
            if (isset($newsomatic_Main_Settings['rule_timeout'])) {
                $rule_timeout = $newsomatic_Main_Settings['rule_timeout'];
            } else {
                $rule_timeout = '';
            }
            if (isset($newsomatic_Main_Settings['strip_links'])) {
                $strip_links = $newsomatic_Main_Settings['strip_links'];
            } else {
                $strip_links = '';
            }
            if (isset($newsomatic_Main_Settings['fix_html'])) {
                $fix_html = $newsomatic_Main_Settings['fix_html'];
            } else {
                $fix_html = '';
            }
            if (isset($newsomatic_Main_Settings['new_category'])) {
                $new_category = $newsomatic_Main_Settings['new_category'];
            } else {
                $new_category = '';
            }
            if (isset($newsomatic_Main_Settings['skip_no_class'])) {
                $skip_no_class = $newsomatic_Main_Settings['skip_no_class'];
            } else {
                $skip_no_class = '';
            }
            if (isset($newsomatic_Main_Settings['no_import_full'])) {
                $no_import_full = $newsomatic_Main_Settings['no_import_full'];
            } else {
                $no_import_full = '';
            }
            if (isset($newsomatic_Main_Settings['no_import_no_class'])) {
                $no_import_no_class = $newsomatic_Main_Settings['no_import_no_class'];
            } else {
                $no_import_no_class = '';
            }
            if (isset($newsomatic_Main_Settings['strip_scripts'])) {
                $strip_scripts = $newsomatic_Main_Settings['strip_scripts'];
            } else {
                $strip_scripts = '';
            }
            if (isset($newsomatic_Main_Settings['send_email'])) {
                $send_email = $newsomatic_Main_Settings['send_email'];
            } else {
                $send_email = '';
            }
            if (isset($newsomatic_Main_Settings['email_address'])) {
                $email_address = $newsomatic_Main_Settings['email_address'];
            } else {
                $email_address = '';
            }
            if (isset($newsomatic_Main_Settings['rel_canonical'])) {
                $rel_canonical = $newsomatic_Main_Settings['rel_canonical'];
            } else {
                $rel_canonical = '';
            }
            if (isset($newsomatic_Main_Settings['shortest_api'])) {
                $shortest_api = $newsomatic_Main_Settings['shortest_api'];
            } else {
                $shortest_api = '';
            }
            if (isset($newsomatic_Main_Settings['link_source'])) {
                $link_source = $newsomatic_Main_Settings['link_source'];
            } else {
                $link_source = '';
            }
            if (isset($newsomatic_Main_Settings['date_format'])) {
                $date_format = $newsomatic_Main_Settings['date_format'];
            } else {
                $date_format = '';
            }
            if (isset($newsomatic_Main_Settings['translate'])) {
                $translate = $newsomatic_Main_Settings['translate'];
            } else {
                $translate = '';
            }
            if (isset($newsomatic_Main_Settings['translate_source'])) {
                $translate_source = $newsomatic_Main_Settings['translate_source'];
            } else {
                $translate_source = '';
            }
            if (isset($newsomatic_Main_Settings['spin_text'])) {
                $spin_text = $newsomatic_Main_Settings['spin_text'];
            } else {
                $spin_text = '';
            }
            if (isset($newsomatic_Main_Settings['best_user'])) {
                $best_user = $newsomatic_Main_Settings['best_user'];
            } else {
                $best_user = '';
            }
            if (isset($newsomatic_Main_Settings['no_title_spin'])) {
                $no_title_spin = $newsomatic_Main_Settings['no_title_spin'];
            } else {
                $no_title_spin = '';
            }
            if (isset($newsomatic_Main_Settings['best_password'])) {
                $best_password = $newsomatic_Main_Settings['best_password'];
            } else {
                $best_password = '';
            }
            if (isset($newsomatic_Main_Settings['min_word_title'])) {
                $min_word_title = $newsomatic_Main_Settings['min_word_title'];
            } else {
                $min_word_title = '';
            }
            if (isset($newsomatic_Main_Settings['max_word_title'])) {
                $max_word_title = $newsomatic_Main_Settings['max_word_title'];
            } else {
                $max_word_title = '';
            }
            if (isset($newsomatic_Main_Settings['min_word_content'])) {
                $min_word_content = $newsomatic_Main_Settings['min_word_content'];
            } else {
                $min_word_content = '';
            }
            if (isset($newsomatic_Main_Settings['max_word_content'])) {
                $max_word_content = $newsomatic_Main_Settings['max_word_content'];
            } else {
                $max_word_content = '';
            }
            if (isset($newsomatic_Main_Settings['required_words'])) {
                $required_words = $newsomatic_Main_Settings['required_words'];
            } else {
                $required_words = '';
            }
            if (isset($newsomatic_Main_Settings['banned_words'])) {
                $banned_words = $newsomatic_Main_Settings['banned_words'];
            } else {
                $banned_words = '';
            }
            if (isset($newsomatic_Main_Settings['skip_old'])) {
                $skip_old = $newsomatic_Main_Settings['skip_old'];
            } else {
                $skip_old = '';
            }
            if (isset($newsomatic_Main_Settings['skip_day'])) {
                $skip_day = $newsomatic_Main_Settings['skip_day'];
            } else {
                $skip_day = '';
            }
            if (isset($newsomatic_Main_Settings['skip_month'])) {
                $skip_month = $newsomatic_Main_Settings['skip_month'];
            } else {
                $skip_month = '';
            }
            if (isset($newsomatic_Main_Settings['skip_year'])) {
                $skip_year = $newsomatic_Main_Settings['skip_year'];
            } else {
                $skip_year = '';
            }
            if (isset($newsomatic_Main_Settings['custom_html2'])) {
                $custom_html2 = $newsomatic_Main_Settings['custom_html2'];
            } else {
                $custom_html2 = '';
            }
            if (isset($newsomatic_Main_Settings['custom_html'])) {
                $custom_html = $newsomatic_Main_Settings['custom_html'];
            } else {
                $custom_html = '';
            }
            if (isset($newsomatic_Main_Settings['skip_no_img'])) {
                $skip_no_img = $newsomatic_Main_Settings['skip_no_img'];
            } else {
                $skip_no_img = '';
            }
            if (isset($newsomatic_Main_Settings['strip_by_id'])) {
                $strip_by_id = $newsomatic_Main_Settings['strip_by_id'];
            } else {
                $strip_by_id = '';
            }
            if (isset($newsomatic_Main_Settings['strip_by_class'])) {
                $strip_by_class = $newsomatic_Main_Settings['strip_by_class'];
            } else {
                $strip_by_class = '';
            }
            if (isset($newsomatic_Main_Settings['read_more'])) {
                $read_more = $newsomatic_Main_Settings['read_more'];
            } else {
                $read_more = '';
            }
            if (isset($newsomatic_Main_Settings['deepl_auth'])) {
                $deepl_auth = $newsomatic_Main_Settings['deepl_auth'];
            } else {
                $deepl_auth = '';
            }
            if (isset($newsomatic_Main_Settings['app_id'])) {
                $app_id = $newsomatic_Main_Settings['app_id'];
            } else {
                $app_id = '';
            }
            if (isset($newsomatic_Main_Settings['resize_width'])) {
                $resize_width = $newsomatic_Main_Settings['resize_width'];
            } else {
                $resize_width = '';
            }
            if (isset($newsomatic_Main_Settings['no_local_image'])) {
                $no_local_image = $newsomatic_Main_Settings['no_local_image'];
            } else {
                $no_local_image = '';
            }
            if (isset($newsomatic_Main_Settings['resize_height'])) {
                $resize_height = $newsomatic_Main_Settings['resize_height'];
            } else {
                $resize_height = '';
            }
            if (isset($newsomatic_Main_Settings['do_not_check_duplicates'])) {
                $do_not_check_duplicates = $newsomatic_Main_Settings['do_not_check_duplicates'];
            } else {
                $do_not_check_duplicates = '';
            }
            if (isset($newsomatic_Main_Settings['no_check'])) {
                $no_check = $newsomatic_Main_Settings['no_check'];
            } else {
                $no_check = '';
            }
            if (isset($newsomatic_Main_Settings['max_query'])) {
                $max_query = $newsomatic_Main_Settings['max_query'];
            } else {
                $max_query = '';
            }
            if (isset($newsomatic_Main_Settings['custom_ciphers'])) {
                $custom_ciphers = $newsomatic_Main_Settings['custom_ciphers'];
            } else {
                $custom_ciphers = '';
            }
            if (isset($newsomatic_Main_Settings['secret_word'])) {
                $secret_word = $newsomatic_Main_Settings['secret_word'];
            } else {
                $secret_word = '';
            }
            if (isset($newsomatic_Main_Settings['require_all'])) {
                $require_all = $newsomatic_Main_Settings['require_all'];
            } else {
                $require_all = '';
            }
            if (isset($newsomatic_Main_Settings['no_link_translate'])) {
                $no_link_translate = $newsomatic_Main_Settings['no_link_translate'];
            } else {
                $no_link_translate = '';
            }
            if (isset($newsomatic_Main_Settings['skip_failed_tr'])) {
                $skip_failed_tr = $newsomatic_Main_Settings['skip_failed_tr'];
            } else {
                $skip_failed_tr = '';
            }
            if (isset($newsomatic_Main_Settings['proxy_auth'])) {
                $proxy_auth = $newsomatic_Main_Settings['proxy_auth'];
            } else {
                $proxy_auth = '';
            }
            if (isset($newsomatic_Main_Settings['proxy_url'])) {
                $proxy_url = $newsomatic_Main_Settings['proxy_url'];
            } else {
                $proxy_url = '';
            }
            if (isset($newsomatic_Main_Settings['scrapeimg_height'])) {
                $scrapeimg_height = $newsomatic_Main_Settings['scrapeimg_height'];
            } else {
                $scrapeimg_height = '';
            }
            if (isset($newsomatic_Main_Settings['attr_text'])) {
                $attr_text = $newsomatic_Main_Settings['attr_text'];
            } else {
                $attr_text = '';
            }
            if (isset($newsomatic_Main_Settings['scrapeimg_width'])) {
                $scrapeimg_width = $newsomatic_Main_Settings['scrapeimg_width'];
            } else {
                $scrapeimg_width = '';
            }
            if (isset($newsomatic_Main_Settings['scrapeimg_cat'])) {
                $scrapeimg_cat = $newsomatic_Main_Settings['scrapeimg_cat'];
            } else {
                $scrapeimg_cat = '';
            }
            if (isset($newsomatic_Main_Settings['scrapeimg_order'])) {
                $scrapeimg_order = $newsomatic_Main_Settings['scrapeimg_order'];
            } else {
                $scrapeimg_order = '';
            }
            if (isset($newsomatic_Main_Settings['scrapeimg_orientation'])) {
                $scrapeimg_orientation = $newsomatic_Main_Settings['scrapeimg_orientation'];
            } else {
                $scrapeimg_orientation = '';
            }
            if (isset($newsomatic_Main_Settings['imgtype'])) {
                $imgtype = $newsomatic_Main_Settings['imgtype'];
            } else {
                $imgtype = '';
            }
            if (isset($newsomatic_Main_Settings['img_order'])) {
                $img_order = $newsomatic_Main_Settings['img_order'];
            } else {
                $img_order = '';
            }
            if (isset($newsomatic_Main_Settings['scrapeimgtype'])) {
                $scrapeimgtype = $newsomatic_Main_Settings['scrapeimgtype'];
            } else {
                $scrapeimgtype = '';
            }
            if (isset($newsomatic_Main_Settings['pixabay_scrape'])) {
                $pixabay_scrape = $newsomatic_Main_Settings['pixabay_scrape'];
            } else {
                $pixabay_scrape = '';
            }
            if (isset($newsomatic_Main_Settings['img_editor'])) {
                $img_editor = $newsomatic_Main_Settings['img_editor'];
            } else {
                $img_editor = '';
            }
            if (isset($newsomatic_Main_Settings['img_language'])) {
                $img_language = $newsomatic_Main_Settings['img_language'];
            } else {
                $img_language = '';
            }
            if (isset($newsomatic_Main_Settings['img_ss'])) {
                $img_ss = $newsomatic_Main_Settings['img_ss'];
            } else {
                $img_ss = '';
            }
            if (isset($newsomatic_Main_Settings['img_mwidth'])) {
                $img_mwidth = $newsomatic_Main_Settings['img_mwidth'];
            } else {
                $img_mwidth = '';
            }
            if (isset($newsomatic_Main_Settings['img_width'])) {
                $img_width = $newsomatic_Main_Settings['img_width'];
            } else {
                $img_width = '';
            }
            if (isset($newsomatic_Main_Settings['img_cat'])) {
                $img_cat = $newsomatic_Main_Settings['img_cat'];
            } else {
                $img_cat = '';
            }
            if (isset($newsomatic_Main_Settings['pixabay_api'])) {
                $pixabay_api = $newsomatic_Main_Settings['pixabay_api'];
            } else {
                $pixabay_api = '';
            }
            if (isset($newsomatic_Main_Settings['pexels_api'])) {
                $pexels_api = $newsomatic_Main_Settings['pexels_api'];
            } else {
                $pexels_api = '';
            }
            if (isset($newsomatic_Main_Settings['morguefile_secret'])) {
                $morguefile_secret = $newsomatic_Main_Settings['morguefile_secret'];
            } else {
                $morguefile_secret = '';
            }
            if (isset($newsomatic_Main_Settings['morguefile_api'])) {
                $morguefile_api = $newsomatic_Main_Settings['morguefile_api'];
            } else {
                $morguefile_api = '';
            }
            if (isset($newsomatic_Main_Settings['bimage'])) {
                $bimage = $newsomatic_Main_Settings['bimage'];
            } else {
                $bimage = '';
            }
            if (isset($newsomatic_Main_Settings['no_orig'])) {
                $no_orig = $newsomatic_Main_Settings['no_orig'];
            } else {
                $no_orig = '';
            }
            if (isset($newsomatic_Main_Settings['flickr_order'])) {
                $flickr_order = $newsomatic_Main_Settings['flickr_order'];
            } else {
                $flickr_order = '';
            }
            if (isset($newsomatic_Main_Settings['flickr_license'])) {
                $flickr_license = $newsomatic_Main_Settings['flickr_license'];
            } else {
                $flickr_license = '';
            }
            if (isset($newsomatic_Main_Settings['flickr_api'])) {
                $flickr_api = $newsomatic_Main_Settings['flickr_api'];
            } else {
                $flickr_api = '';
            }
            $get_option_viewed = get_option('xxxxsettings_viewedx', 0);
            if ($get_option_viewed == 0) {
            ?>

         <?php
            }
            if (isset($_GET['settings-updated'])) {
            ?>
         <div id="message" class="updated">
            <p class="cr_saved_notif"><strong>&nbsp;<?php echo esc_html__('Settings saved.');?></strong></p>
         </div>
         <?php
            $get = get_option('coderevolution_settings_changed', 0);
            if($get == 1)
            {
                delete_option('coderevolution_settings_changed');
            ?>
         <div id="message" class="updated">
            <p class="cr_failed_notif"><strong>&nbsp;<?php echo esc_html__('Plugin registration failed!');?></strong></p>
         </div>
         <?php 
            }
            elseif($get == 2)
            {
                    delete_option('coderevolution_settings_changed');
            ?>
         <div id="message" class="updated">
            <p class="cr_saved_notif"><strong>&nbsp;<?php echo esc_html__('Plugin registration successful!');?></strong></p>
         </div>
         <?php 
            }
                }
            ?>




<?php include('newsomatic-mainmenu.php'); ?>



 <!-- //////////////////////////////////////////////////////////////////////////// --> 
<!-- START CONTAINER -->
<div class="container-padding">
         <div>
            <div class="hideMain">

<!-- Start row -->
  <div class="row options-listed options-setup-keys">
    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
         Setup keys
        </div>
            <div class="panel-body">
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo sprintf( wp_kses( __( "Insert your News API Key. Get one <a href='%s' target='_blank'>here</a>."), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://newsapi.org/register' ) );
                                    ?>
                              </div>
                           </div>
                           <b class="cr_red12"><a href='https://newsapi.org/register' target='_blank'><?php echo esc_html__("NewsAPI API Key");?></a>:</b>
                        </div>

                        <div>
                           <input class="form-control" type="password" autocomplete="off" id="app_id" name="newsomatic_Main_Settings[app_id]" value="<?php
                              echo esc_html($app_id);
                              ?>" placeholder="<?php echo esc_html__("Please insert your NewsAPI API Key");?>">
                        </div><br/><br/>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo sprintf( wp_kses( __( "If you wish to use Deepl for translation, you must enter first a Deepl 'Authentication Key'. Get one <a href='%s' target='_blank'>here</a>. If you enter a value here, new options will become available in the 'Automatically Translate Content To' and 'Source Language' fields."), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://www.deepl.com/subscription.html' ) );
                                    ?>
                              </div>
                           </div>
                           <b><a href="https://www.deepl.com/subscription.html" target="_blank"><?php echo esc_html__("Deepl Translator Authentication Key (Optional)");?>:</a></b>
                        </div>

                        <div>
                           <input type="password" autocomplete="off" id="deepl_auth" placeholder="<?php echo esc_html__("Auth key (optional)");?>" name="newsomatic_Main_Settings[deepl_auth]" value="<?php
                              echo esc_html($deepl_auth);
                              ?>"/>
                        </div>
                    <br/><input type="submit" name="btnSubmitApp" id="btnSubmitApp" class="btn btn-default" onclick="unsaved = false;" value="<?php echo esc_html__("Save Info");?>"/>
            </div>

      </div>
    </div>

  </div>
  <!-- End row -->


<!-- Start row -->
  <div class="row options-listed options-plugin-options">


    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
         Plugin Options
        </div>

            <div class="panel-body">
<table>


                  <tr style="display:none;">
                     <td>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text cr_min_260px">
                              <?php
                                 echo esc_html__("Check this to force the plugin not check generated posts in rule settings. Improves performance if you have 100k posts generated using this plugin.");
                                 ?>
                           </div>
                        </div>
                        <b><?php echo esc_html__("Do Not Check Generated Posts In Rule Settings:");?></b>
                     </td>
                     <td>
                        <input type="checkbox" id="no_check" name="newsomatic_Main_Settings[no_check]"<?php
                           if ($no_check == 'on')
                               echo ' checked ';
                           ?>>
            </div>
            </td></tr>
            <tr style="display:none;"><td>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
            <div class="bws_hidden_help_text cr_min_260px">
            <?php
               echo esc_html__("Set if the plugin should query NewsAPI with maximum sized requests. If you uncheck this checkbox, the plugin will query the API strictly with the queried post count.");
               ?>
            </div>
            </div>
            <b><?php echo esc_html__("Query As Many Post As Possible From NewsAPI:");?></b>
            </td><td>
            <input type="checkbox" id="max_query" name="newsomatic_Main_Settings[max_query]"<?php
               if ($max_query == 'on')
                   echo ' checked ';
               ?>>
         </div>
         </td></tr>
         <tr style="display:none;"><td>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
         <div class="bws_hidden_help_text cr_min_260px">
         <?php
            echo esc_html__("This is a debug feature (experimental). Input a cipher list, if you get this (or similar) error in curl requests: 'gnutls_handshake() failed: A TLS packet with unexpected length was received.'");
            ?>
         </div>
         </div>
         <b><?php echo esc_html__("Allow Custom Ciphers In Curl Requests:");?></b>
         </td><td>
         <input type="text" id="custom_ciphers" placeholder="<?php echo esc_html__("Input a cipher list");?>" name="newsomatic_Main_Settings[custom_ciphers]" value="<?php
            echo esc_html($custom_ciphers);
            ?>"/>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Select a secret word that will be used when you run the plugin manually/by cron. See details about this below.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Secret Word Used For Manual/Cron Running:");?></b>
   </td><td>
   <input type="text" id="secret_word" name="newsomatic_Main_Settings[secret_word]" value="<?php echo esc_html($secret_word);?>" placeholder="<?php echo esc_html__("Input a secret word");?>">
   </div>
   </td></tr>
   <tr style="display:none;"><td colspan="2">
   <div>
   <br/><b><?php echo esc_html__("If you want to schedule the cron event manually in your server, you should schedule this address:");?> <span class="cr_red"><?php if($secret_word != '') { echo get_site_url() . '/?run_newsomatic=' . $secret_word;} else { echo esc_html__('You must enter a secret word above, to use this feature.'); }?></span><br/><?php echo esc_html__("Example:");?> <span class="cr_red"><?php if($secret_word != '') { echo '15,45****wget -q -O /dev/null ' . get_site_url() . '/?run_newsomatic=' . $secret_word;} else { echo esc_html__('You must enter a secret word above, to use this feature.'); }?></span></b></div><br/><br/>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Choose if you want to show an extended information metabox under every plugin generated post.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Show Extended Item Information Metabox in Post:");?></b>
   </td><td>
   <input type="checkbox" id="enable_metabox" name="newsomatic_Main_Settings[enable_metabox]"<?php
      if ($enable_metabox == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do you want to enable logging for rules?");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Enable Logging for Rules:");?></b>
   </td><td>
   <input type="checkbox" id="enable_logging" name="newsomatic_Main_Settings[enable_logging]" onclick="mainChanged()"<?php
      if ($enable_logging == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div class="hideLog">
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do you want to enable detailed logging for rules? Note that this will dramatically increase the size of the log this plugin generates.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Enable Detailed Logging for Rules:");?></b>
   </div>
   </td><td>
   <div class="hideLog">
   <input type="checkbox" id="enable_detailed_logging" name="newsomatic_Main_Settings[enable_detailed_logging]"<?php
      if ($enable_detailed_logging == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div class="hideLog">
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Choose if you want to automatically clear logs after a period of time.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Automatically Clear Logs After:");?></b>
   </div>
   </td><td>
   <div class="hideLog">
   <select id="auto_clear_logs" name="newsomatic_Main_Settings[auto_clear_logs]" >
   <option value="No"<?php
      if ($auto_clear_logs == "No") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Disabled");?></option>
   <option value="monthly"<?php
      if ($auto_clear_logs == "monthly") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Once a month");?></option>
   <option value="weekly"<?php
      if ($auto_clear_logs == "weekly") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Once a week");?></option>
   <option value="daily"<?php
      if ($auto_clear_logs == "daily") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Once a day");?></option>
   <option value="twicedaily"<?php
      if ($auto_clear_logs == "twicedaily") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Twice a day");?></option>
   <option value="hourly"<?php
      if ($auto_clear_logs == "hourly") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Once an hour");?></option>
   </select>    
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Set the user-agent to use when downloading web pages.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("User-Agent To Use When Getting Web Pages:");?></b>
   </div>
   </td><td>
   <div>
   <input type="text" id="user_agent" placeholder="<?php echo esc_html__("Input a user agent");?>" name="newsomatic_Main_Settings[user_agent]" value="<?php
      echo esc_html($user_agent);
      ?>"/>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("If you want to use a proxy to crawl webpages, input it's address here. Required format: IP Address/URL:port");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Web Proxy Address:");?></b>
   </div>
   </td><td>
   <div>
   <input type="text" id="proxy_url" placeholder="<?php echo esc_html__("Input web proxy url");?>" name="newsomatic_Main_Settings[proxy_url]" value="<?php echo esc_html($proxy_url);?>"/>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("If you want to use a proxy to crawl webpages, and it requires authentification, input it's authentification details here. Required format: username:password");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Web Proxy Authentification:");?></b>
   </div>
   </td><td>
   <div>
   <input type="text" id="proxy_auth" placeholder="<?php echo esc_html__("Input web proxy auth");?>" name="newsomatic_Main_Settings[proxy_auth]" value="<?php echo esc_html($proxy_auth);?>"/>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Set the timeout (in seconds) for every rule running. I recommend that you leave this field at it's default value (3600).");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Timeout for Rule Running (seconds):");?></b>
   </div>
   </td><td>
   <div>
   <input type="number" id="rule_timeout" step="1" min="0" class="cr_width_full" placeholder="<?php echo esc_html__("Input rule timeout in seconds");?>" name="newsomatic_Main_Settings[rule_timeout]" value="<?php
      echo esc_html($rule_timeout);
      ?>"/>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Choose if you want to receive a summary of the rule running in an email.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Send Rule Running Summary in Email:");?></b>
   </td><td>
   <input type="checkbox" id="send_email" name="newsomatic_Main_Settings[send_email]" onchange="mainChanged()"<?php
      if ($send_email == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div class="hideMail">
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Input the email adress where you want to send the report. You can input more email addresses, separated by commas.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Email Address:");?></b>
   </div>
   </td><td>
   <div class="hideMail">
   <input type="email" id="email_address" placeholder="<?php echo esc_html__("Input a valid email adress");?>" name="newsomatic_Main_Settings[email_address]" value="<?php
      echo esc_html($email_address);
      ?>">
   </div>
   </td></tr>


<tr><td><div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-default" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings");?>"/></p></div></td><td></td></tr>

</table>


</div></div></div></div>

<!-- Start row -->
  <div class="row options-listed options-post-content-options">


    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
        Post Content Options
        </div>

            <div class="panel-body">

<table>


                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose if you want to skip checking for duplicate posts when publishing new posts (check this if you have 10000+ posts on your blog and you are experiencing slowdows when the plugin is running. If you check this, duplicate posts will be posted! So use it only when it is necesarry.");
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Do Not Check For Duplicate Posts:");?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="do_not_check_duplicates" name="newsomatic_Main_Settings[do_not_check_duplicates]"<?php
                        if ($do_not_check_duplicates == 'on')
                            echo ' checked ';
                        ?>>
                     </div>
                     </td>
                  </tr>
	
<tr style="display:none;">
   <?php
      if($shortest_api == '')
      {
          echo '<td colspan="2"><span><b>To enable outgoing link monetization, <a href="http://join-shortest.com/ref/ff421f2b06?user-type=new" target="_blank">sign up for a Shorte.st account here</a></b>. To get your API token after you have signed up, click <a href="https://shorte.st/tools/api?user-type=new" target="_blank">here</a>.</span><br/></td>';
      }
      ?>
   <td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo sprintf( wp_kses( __( "If you wish to shorten outgoing links using shorte.st, please enter your API token here. To sign up for a new account, click <a href='%s' target='_blank'>here</a>. To get your API token after you have signed up, click <a href='%s' target='_blank'>here</a>. To disable URL shortening, leave this field blank."), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( "http://join-shortest.com/ref/ff421f2b06?user-type=new" ), esc_url( 'https://shorte.st/tools/api?user-type=new'));
      ?>
   </div>
   </div>
   <b><a href="http://join-shortest.com/ref/ff421f2b06?user-type=new" target="_blank"><?php echo esc_html__("Shorte.st API Token");?></a>:</b>
   </td><td>
   <input type="text" name="newsomatic_Main_Settings[shortest_api]" value="<?php
      echo esc_html($shortest_api);
      ?>" placeholder="<?php echo esc_html__("Shorte.st API token");?>">
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Select if you want to link generated post titles to source articles. This option will be overwritten if you set it also from rule settings.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Link Generated Post Titles To Source Articles:");?></b>
   </td><td>
   <input type="checkbox" id="link_source" name="newsomatic_Main_Settings[link_source]"<?php
      if ($link_source == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Select if you want to add a 'rel=canonical' meta tag to generated posts, linking back to the source of the article.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Add \"rel=canonical\" Meta Tag To Generated Posts:");?></b>
   </td><td>
   <input type="checkbox" id="rel_canonical" name="newsomatic_Main_Settings[rel_canonical]"<?php
      if ($rel_canonical == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo sprintf( wp_kses( __( "Set the date format for the %%item_date%% shortcode. Example: Y-m-d H:i:s . You can read more about date formats, <a href='%s' target='_blank'>here</a>. To leave this at it's default value, leave this field blank."), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'http://php.net/manual/ro/function.date.php' ) );
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Date Format for the %%item_date%% Shortcode:");?></b>
   </td><td>
   <input type="text" id="date_format" name="newsomatic_Main_Settings[date_format]" placeholder="<?php echo esc_html__("Add a date format");?>" value="<?php echo esc_html($date_format);?>">
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Choose if you want to skip full content importing for posts that don't have the class/id defined in the 'HTML Search Query String' rule parameter. If you uncheck this, the automatic text detection will be used to extract full content from the article. This checkbox is useful for some video CNN articles, which have different article structure from normal textual articles, and can have broken content imported from them.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Use Original Post Content For Posts That Don't Match Defined Importing HTML Class/ID:");?></b>
   </td><td>
   <input type="checkbox" id="skip_no_class" name="newsomatic_Main_Settings[skip_no_class]"<?php
      if ($skip_no_class == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Choose if you want to full skip posts that don't match the html class or id you defined. This will work only if the previous checkbox is checked.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Skip Posts That Don't Match Defined Importing HTML Class/ID:");?></b>
   </td><td>
   <input type="checkbox" id="no_import_full" name="newsomatic_Main_Settings[no_import_full]"<?php
      if ($no_import_full == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Choose if you want to skip posts that don't get extracted correctly (full content).");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Skip Posts That Are Not Extracted Correctly:");?></b>
   </td><td>
   <input type="checkbox" id="no_import_no_class" name="newsomatic_Main_Settings[no_import_no_class]"<?php
      if ($no_import_no_class == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Choose if you the plugin to generate new categories if the category does not already exist.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Do Not Generate Inexistent Categories for New Posts:");?></b>
   </td><td>
   <input type="checkbox" id="new_category" name="newsomatic_Main_Settings[new_category]"<?php
      if ($new_category == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Choose if you want to strip links from the generated post content.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Strip Links From Generated Post Content:");?></b>
   </td><td>
   <input type="checkbox" id="strip_links" name="newsomatic_Main_Settings[strip_links]"<?php
      if ($strip_links == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do you want to try to fix html tags that were incorrectly grabbed from source?");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Try To Fix Html Tags From Generated Posts Content:");?></b>
   </td><td>
   <input type="checkbox" id="fix_html" name="newsomatic_Main_Settings[fix_html]"<?php
      if ($fix_html == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Choose if you want to strip JavaScript from the crawled post content.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Strip JavaScript From Crawled Content:");?></b>
   </td><td>
   <input type="checkbox" id="strip_scripts" name="newsomatic_Main_Settings[strip_scripts]"<?php
      if ($strip_scripts == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Strip HTML elements from final content that have this IDs. You can insert more IDs, separeted by comma. To disable this feature, leave this field blank.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Strip HTML Elements from Final Content by ID:");?></b>
   </td><td>
   <textarea rows="3" cols="70" name="newsomatic_Main_Settings[strip_by_id]" placeholder="<?php echo esc_html__("Ids list");?>"><?php
      echo esc_textarea($strip_by_id);
      ?></textarea>
   </div>
   </td></tr>
   <tr style="display:none;"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Strip HTML elements from final content that have this class. You can insert more classes, separeted by comma. To disable this feature, leave this field blank.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Strip HTML Elements from Final Content by Class:");?></b>
   </td><td>
   <textarea rows="3" cols="70" name="newsomatic_Main_Settings[strip_by_class]" placeholder="<?php echo esc_html__("Class list");?>"><?php
      echo esc_textarea($strip_by_class);
      ?></textarea>
   </div>
   </td></tr>
   <tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Set the 'Read More' button text. This button is generated using the %%item_read_more_button%% shortcode. If you leave this field blank, the default value is 'Read More'.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("'Read More' Button Text:");?></b>
   </div>
   </td><td>
   <div>
   <input type="text" id="read_more" placeholder="<?php echo esc_html__("Read More");?>" name="newsomatic_Main_Settings[read_more]" value="<?php
      echo esc_html($read_more);
      ?>"/>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo sprintf( wp_kses( __( "Do you want to automatically translate generated content using? This settings is overwritten if you define translation settings from within the importing rule settings. If you wish to use Deepl for translation, you must enter first a Deepl 'Authentication Key'. Get one <a href='%s' target='_blank'>here</a>."), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( 'https://www.deepl.com/subscription.html' ) );
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Automatically Translate Content To (Global):");?></b>
   </div>
   </td><td>
   <div>
   <select id="translate" name="newsomatic_Main_Settings[translate]" >
   <?php
      $i = 0;
      foreach ($language_names as $lang) {
          echo '<option value="' . esc_html($language_codes[$i]) . '"';
          if ($translate == $language_codes[$i]) {
              echo ' selected';
          }
          echo '>' . esc_html($language_names[$i]) . '</option>';
          $i++;
      }
      if($deepl_auth != '')
      {
          $i = 0;
          foreach ($language_names_deepl as $lang) {
              echo '<option value="' . esc_html($language_codes_deepl[$i]) . '"';
              if ($translate == $language_codes_deepl[$i]) {
                  echo ' selected';
              }
              echo '>' . esc_html($language_names_deepl[$i]) . '</option>';
              $i++;
          }
      }
      ?>
   </select>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do you want to automatically translate generated content using Google Translate? Here you can define the translation's source language. This settings is overwritten if you define translation settings from within the importing rule settings.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Translation Source Language (Global):");?></b>
   </div>
   </td><td>
   <div>
   <select id="translate_source" name="newsomatic_Main_Settings[translate_source]" >
   <?php
      $i = 0;
      foreach ($language_names as $lang) {
          echo '<option value="' . esc_html($language_codes[$i]) . '"';
          if ($translate_source == $language_codes[$i]) {
              echo ' selected';
          }
          echo '>' . esc_html($language_names[$i]) . '</option>';
          $i++;
      }
      if($deepl_auth != '')
      {
          $i = 0;
          foreach ($language_names_deepl as $lang) {
              echo '<option value="' . esc_html($language_codes_deepl[$i]) . '"';
              if ($translate == $language_codes_deepl[$i]) {
                  echo ' selected';
              }
              echo '>' . esc_html($language_names_deepl[$i]) . '</option>';
              $i++;
          }
      }
      ?>
   </select>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Choose if you want to import also posts that were not translated correctly - they will be imported in original language. If you check this, posts that failed translation will be not imported.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Skip Posts That Did Not Translate Correctly:");?></b>
   </td><td>
   <input type="checkbox" id="skip_failed_tr" name="newsomatic_Main_Settings[skip_failed_tr]"<?php
      if ($skip_failed_tr == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do you want to keep original link sources after translation? If you uncheck this, links will point to Google Translate version of the linked website.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Keep Original Link Source After Translation:");?></b>
   </td><td>
   <input type="checkbox" id="no_link_translate" name="newsomatic_Main_Settings[no_link_translate]"<?php
      if ($no_link_translate == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr><tr><td>
   <div id="bestspin"><p><?php echo esc_html__("Don't have an 'The Best Spinner' account yet? Click here to get one:");?> <b><a href="https://coderevolution.jonathanleger.zaxaa.com/s/4152959114554" target="_blank"><?php echo esc_html__("get a new account now!");?></a></b></p></div>
   <div id="wordai"><p><?php echo esc_html__("Don't have an 'WordAI' account yet? Click here to get one:");?> <b><a href="https://wordai.com/?ref=h17f4" target="_blank"><?php echo esc_html__("get a new account now!");?></a></b></p></div>
   <div id="spinrewriter"><p><?php echo esc_html__("Don't have an 'SpinRewriter' account yet? Click here to get one:");?> <b><a href="https://www.spinrewriter.com/?ref=24b18" target="_blank"><?php echo esc_html__("get a new account now!");?></a></b></p></div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do you want to randomize text by changing words of a text with synonyms using one of the listed methods? Note that this is an experimental feature and can in some instances drastically increase the rule running time!");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Spin Text Using Word Synonyms (for automatically generated posts only):");?></b>
   </td><td>
   <select id="spin_text" name="newsomatic_Main_Settings[spin_text]" onchange="mainChanged()">
   <option value="disabled"
      <?php
         if ($spin_text == 'disabled') {
             echo ' selected';
         }
         ?>
      ><?php echo esc_html__("Disabled");?></option>
   <option value="best"
      <?php
         if ($spin_text == 'best') {
             echo ' selected';
         }
         ?>
      >The Best Spinner - <?php echo esc_html__("High Quality - Paid");?></option>
   <option value="wordai"
      <?php
         if($spin_text == 'wordai')
                 {
                     echo ' selected';
                 }
         ?>
      >Wordai - <?php echo esc_html__("High Quality - Paid");?></option>
   <option value="spinrewriter"
      <?php
         if($spin_text == 'spinrewriter')
                 {
                     echo ' selected';
                 }
         ?>
      >SpinRewriter - <?php echo esc_html__("High Quality - Paid");?></option>
   <option value="builtin"
      <?php
         if ($spin_text == 'builtin') {
             echo ' selected';
         }
         ?>
      ><?php echo esc_html__("Built-in - Medium Quality - Free");?></option>
   <option value="wikisynonyms"
      <?php
         if ($spin_text == 'wikisynonyms') {
             echo ' selected';
         }
         ?>
      >WikiSynonyms - <?php echo esc_html__("Low Quality - Free");?></option>
   <option value="freethesaurus"
      <?php
         if ($spin_text == 'freethesaurus') {
             echo ' selected';
         }
         ?>
      >FreeThesaurus - <?php echo esc_html__("Low Quality - Free");?></option>
   </select>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do you want to not spin title (only content)?");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Do Not Spin Title:");?></b>
   </div>
   </td><td>
   <div>
   <input type="checkbox" id="no_title_spin" name="newsomatic_Main_Settings[no_title_spin]"<?php
      if ($no_title_spin == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr><tr><td>
   <div class="hideBest">
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Insert your user name on premium spinner service.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Premium Spinner Service User Name/Email:");?></b>
   </div>
   </td><td>
   <div class="hideBest">
   <input type="text" name="newsomatic_Main_Settings[best_user]" value="<?php
      echo esc_html($best_user);
      ?>" placeholder="<?php echo esc_html__("Please insert your premium text spinner service user name");?>">
   </div>
   </td></tr><tr><td>
   <div class="hideBest">
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Insert your password for the selected premium spinner service.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Premium Spinner Service Password/API Key:");?></b>
   </div>
   </td><td>
   <div class="hideBest">
   <input type="password" autocomplete="off" name="newsomatic_Main_Settings[best_password]" value="<?php
      echo esc_html($best_password);
      ?>" placeholder="<?php echo esc_html__("Please insert your premium text spinner service password");?>">
   </div>
   </td></tr>

<tr><td><div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-default" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings");?>"/></p></div></td><td></td></tr>
   
</table>


</div></div></div></div>



<!-- Start row -->
  <div class="row options-listed options-post-restrictions">


    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
        Posting Restrictions
        </div>

            <div class="panel-body">


   <table>
 <tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Set the minimum word count for post titles. Items that have less than this count will not be published. To disable this feature, leave this field blank.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Minimum Title Word Count (Skip Post Otherwise):");?></b>
   </div>
   </td><td>
   <div>
   <input type="number" class="cr_width_full" id="min_word_title" step="1" placeholder="<?php echo esc_html__("Input the minimum word count for the title");?>" min="0" name="newsomatic_Main_Settings[min_word_title]" value="<?php
      echo esc_html($min_word_title);
      ?>"/>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Set the maximum word count for post titles. Items that have more than this count will not be published. To disable this feature, leave this field blank.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Maximum Title Word Count (Skip Post Otherwise):");?></b>
   </div>
   </td><td>
   <div>
   <input type="number" id="max_word_title" class="cr_width_full" step="1" min="0" placeholder="<?php echo esc_html__("Input the maximum word count for the title");?>" name="newsomatic_Main_Settings[max_word_title]" value="<?php
      echo esc_html($max_word_title);
      ?>"/>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Set the minimum word count for post content. Items that have less than this count will not be published. To disable this feature, leave this field blank.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Minimum Content Word Count (Skip Post Otherwise):");?></b>
   </div>
   </td><td>
   <div>
   <input type="number" id="min_word_content" class="cr_width_full" step="1" min="0" placeholder="<?php echo esc_html__("Input the minimum word count for the content");?>" name="newsomatic_Main_Settings[min_word_content]" value="<?php
      echo esc_html($min_word_content);
      ?>"/>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Set the maximum word count for post content. Items that have more than this count will not be published. To disable this feature, leave this field blank.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Maximum Content Word Count (Skip Post Otherwise):");?></b>
   </div>
   </td><td>
   <div>
   <input type="number" id="max_word_content" class="cr_width_full" step="1" min="0" placeholder="<?php echo esc_html__("Input the maximum word count for the content");?>" name="newsomatic_Main_Settings[max_word_content]" value="<?php
      echo esc_html($max_word_content);
      ?>"/>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do not include posts that's title or content contains at least one of these words. Separate words by comma. To disable this feature, leave this field blank.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Banned Words List:");?></b>
   </td><td>
   <textarea rows="1" name="newsomatic_Main_Settings[banned_words]" placeholder="<?php echo esc_html__("Do not generate posts that contain at least one of these words");?>"><?php
      echo esc_textarea($banned_words);
      ?></textarea>
   </div>
   </td></tr>
   <tr class="hidethis"><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do not include posts that's title or content does not contain at least one of these words. Separate words by comma. To disable this feature, leave this field blank.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Required Words List:");?></b>
   </td><td>
   <textarea rows="1" name="newsomatic_Main_Settings[required_words]" placeholder="<?php echo esc_html__("Do not generate posts unless they contain all of these words");?>"><?php
      echo esc_textarea($required_words);
      ?></textarea>
   </div>
   </td></tr>
   <tr class="hidethis"><td>
   <div class="hideLog">
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do you want to all words defined in the required words list? If you uncheck this, if only one word is found, the article will be published.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Require All Words in the 'Required Words List':");?></b>
   </div>
   </td><td>
   <div class="hideLog">
   <input type="checkbox" id="require_all" name="newsomatic_Main_Settings[require_all]"<?php
      if ($require_all == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Choose if you want to skip posts that do not have images.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Skip Posts That Do Not Have Images:");?></b>
   </td><td>
   <input type="checkbox" id="skip_no_img" name="newsomatic_Main_Settings[skip_no_img]"<?php
      if ($skip_no_img == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Choose if you want to skip posts that are older than a selected date.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Skip Posts Older Than a Selected Date:");?></b>
   </td><td>
   <input type="checkbox" id="skip_old" name="newsomatic_Main_Settings[skip_old]" onchange="mainChanged()"<?php
      if ($skip_old == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr><tr><td>
   <div class='hideOld'>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Select the date prior which you want to skip posts.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Select the Date for Old Posts:");?></b>
   </div>
   </td><td>
   <div class='hideOld'>
   <?php echo esc_html__("Day:");?>
   <select class="cr_width_80" name="newsomatic_Main_Settings[skip_day]" >  
   <option value='01'<?php
      if ($skip_day == '01')
          echo ' selected';
      ?>>01</option>
   <option value='02'<?php
      if ($skip_day == '02')
          echo ' selected';
      ?>>02</option>
   <option value='03'<?php
      if ($skip_day == '03')
          echo ' selected';
      ?>>03</option>
   <option value='04'<?php
      if ($skip_day == '04')
          echo ' selected';
      ?>>04</option>
   <option value='05'<?php
      if ($skip_day == '05')
          echo ' selected';
      ?>>05</option>
   <option value='06'<?php
      if ($skip_day == '06')
          echo ' selected';
      ?>>06</option>
   <option value='07'<?php
      if ($skip_day == '07')
          echo ' selected';
      ?>>07</option>
   <option value='08'<?php
      if ($skip_day == '08')
          echo ' selected';
      ?>>08</option>
   <option value='09'<?php
      if ($skip_day == '09')
          echo ' selected';
      ?>>09</option>
   <option value='10'<?php
      if ($skip_day == '10')
          echo ' selected';
      ?>>10</option>
   <option value='11'<?php
      if ($skip_day == '11')
          echo ' selected';
      ?>>11</option>
   <option value='12'<?php
      if ($skip_day == '12')
          echo ' selected';
      ?>>12</option>
   <option value='13'<?php
      if ($skip_day == '13')
          echo ' selected';
      ?>>13</option>
   <option value='14'<?php
      if ($skip_day == '14')
          echo ' selected';
      ?>>14</option>
   <option value='15'<?php
      if ($skip_day == '15')
          echo ' selected';
      ?>>15</option>
   <option value='16'<?php
      if ($skip_day == '16')
          echo ' selected';
      ?>>16</option>
   <option value='17'<?php
      if ($skip_day == '17')
          echo ' selected';
      ?>>17</option>
   <option value='18'<?php
      if ($skip_day == '18')
          echo ' selected';
      ?>>18</option>
   <option value='19'<?php
      if ($skip_day == '19')
          echo ' selected';
      ?>>19</option>
   <option value='20'<?php
      if ($skip_day == '20')
          echo ' selected';
      ?>>20</option>
   <option value='21'<?php
      if ($skip_day == '21')
          echo ' selected';
      ?>>21</option>
   <option value='22'<?php
      if ($skip_day == '22')
          echo ' selected';
      ?>>22</option>
   <option value='23'<?php
      if ($skip_day == '23')
          echo ' selected';
      ?>>23</option>
   <option value='24'<?php
      if ($skip_day == '24')
          echo ' selected';
      ?>>24</option>
   <option value='25'<?php
      if ($skip_day == '25')
          echo ' selected';
      ?>>25</option>
   <option value='26'<?php
      if ($skip_day == '26')
          echo ' selected';
      ?>>26</option>
   <option value='27'<?php
      if ($skip_day == '27')
          echo ' selected';
      ?>>27</option>
   <option value='28'<?php
      if ($skip_day == '28')
          echo ' selected';
      ?>>28</option>
   <option value='29'<?php
      if ($skip_day == '29')
          echo ' selected';
      ?>>29</option>
   <option value='30'<?php
      if ($skip_day == '30')
          echo ' selected';
      ?>>30</option>
   <option value='31'<?php
      if ($skip_day == '31')
          echo ' selected';
      ?>>31</option>
   </select>
   <?php echo esc_html__("Month:");?>
   <select class="cr_width_80" name="newsomatic_Main_Settings[skip_month]" >
   <option value='01'<?php
      if ($skip_month == '01')
          echo ' selected';
      ?>><?php echo esc_html__("January");?></option>
   <option value='02'<?php
      if ($skip_month == '02')
          echo ' selected';
      ?>><?php echo esc_html__("February");?></option>
   <option value='03'<?php
      if ($skip_month == '03')
          echo ' selected';
      ?>><?php echo esc_html__("March");?></option>
   <option value='04'<?php
      if ($skip_month == '04')
          echo ' selected';
      ?>><?php echo esc_html__("April");?></option>
   <option value='05'<?php
      if ($skip_month == '05')
          echo ' selected';
      ?>><?php echo esc_html__("May");?></option>
   <option value='06'<?php
      if ($skip_month == '06')
          echo ' selected';
      ?>><?php echo esc_html__("June");?></option>
   <option value='07'<?php
      if ($skip_month == '07')
          echo ' selected';
      ?>><?php echo esc_html__("July");?></option>
   <option value='08'<?php
      if ($skip_month == '08')
          echo ' selected';
      ?>><?php echo esc_html__("August");?></option>
   <option value='09'<?php
      if ($skip_month == '09')
          echo ' selected';
      ?>><?php echo esc_html__("September");?></option>
   <option value='10'<?php
      if ($skip_month == '10')
          echo ' selected';
      ?>><?php echo esc_html__("October");?></option>
   <option value='11'<?php
      if ($skip_month == '11')
          echo ' selected';
      ?>><?php echo esc_html__("November");?></option>
   <option value='12'<?php
      if ($skip_month == '12')
          echo ' selected';
      ?>><?php echo esc_html__("December");?></option>
   </select>
   <?php echo esc_html__("Year:");?><input class="cr_width_70" value="<?php
      echo esc_html($skip_year);
      ?>" placeholder="<?php echo esc_html__("year");?>" name="newsomatic_Main_Settings[skip_year]" type="text" pattern="^\d{4}$">
   </div>     
   </td></tr>
<tr><td><div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-default" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings");?>"/></p></div></td><td></td></tr>
</table>


</div></div></div></div>























<!-- Start row -->
  <div class="row options-listed options-featured-image-options">


    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
        Featured Image Options:
        </div>

            <div class="panel-body">


<table>
   <tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Click this option if your want to set the featured image from the remote image location. This settings can save disk space, but beware that if the remote image gets deleted, your featured image will also be broken.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Do Not Copy Featured Image Locally:");?></b>
   </td><td>
   <input type="checkbox" id="no_local_image" name="newsomatic_Main_Settings[no_local_image]"<?php
      if ($no_local_image == 'on')
          echo ' checked ';
      ?>>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Resize the image that was assigned to be the featured image to the width specified in this text field (in pixels). If you want to disable this feature, leave this field blank.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Featured Image Resize Width:");?></b>
   </div>
   </td><td>
   <div>
   <input type="number" min="1" step="1" class="cr_width_full" name="newsomatic_Main_Settings[resize_width]" value="<?php echo esc_html($resize_width);?>" placeholder="<?php echo esc_html__("Please insert the desired width for featured images");?>">
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Resize the image that was assigned to be the featured image to the height specified in this text field (in pixels). If you want to disable this feature, leave this field blank.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Featured Image Resize Height:");?></b>
   </div>
   </td><td>
   <div>
   <input type="number" min="1" step="1" class="cr_width_full" name="newsomatic_Main_Settings[resize_height]" value="<?php echo esc_html($resize_height);?>" placeholder="<?php echo esc_html__("Please insert the desired height for featured images");?>">
   </div> 
   </td></tr>
<tr><td><div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-default" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings");?>"/></p></div></td><td></td></tr>
<tr><td><br/><br/><br/></td><td></td></tr>
</table>


</div></div></div></div>


<!-- Start row -->
  <div class="row options-listed options-royalty-free-featured-image-importing">


    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
        Royalty Free Featured Image Importing Options:
        </div>

            <div class="panel-body">

<table>
   <tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo sprintf( wp_kses( __( "Insert your MorgueFile App ID. Register <a href='%s' target='_blank'>here</a>. Learn how to get an API key <a href='%s' target='_blank'>here</a>. If you enter an API Key and an API Secret, you will enable search for images using the MorgueFile API."), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( "https://morguefile.com/?mfr18=37077f5764c83cc98123ef1166ce2aa6" ),  esc_url( "https://morguefile.com/developer" ) );
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("MorgueFile App ID:");?></b>
   </div>
   </td><td>
   <div>
   <input type="text" name="newsomatic_Main_Settings[morguefile_api]" value="<?php
      echo esc_html($morguefile_api);
      ?>" placeholder="<?php echo esc_html__("Please insert your MorgueFile API key");?>">
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo sprintf( wp_kses( __( "Insert your MorgueFile App Secret. Register <a href='%s' target='_blank'>here</a>. Learn how to get an API key <a href='%s' target='_blank'>here</a>. If you enter an API Key and an API Secret, you will enable search for images using the MorgueFile API."), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( "https://morguefile.com/?mfr18=37077f5764c83cc98123ef1166ce2aa6" ),  esc_url( "https://morguefile.com/developer" ) );
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("MorgueFile App Secret:");?></b>
   </div>
   </td><td>
   <div>
   <input type="text" name="newsomatic_Main_Settings[morguefile_secret]" value="<?php
      echo esc_html($morguefile_secret);
      ?>" placeholder="<?php echo esc_html__("Please insert your MorgueFile API Secret");?>">
   </div>
   <tr><td colspan="2"><hr class="cr_dotted"/></td></tr>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo sprintf( wp_kses( __( "Insert your Pexels App ID. Learn how to get an API key <a href='%s' target='_blank'>here</a>. If you enter an API Key and an API Secret, you will enable search for images using the Pexels API."), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( "https://www.pexels.com/api/" ));
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Pexels App ID:");?></b>
   </div>
   </td><td>
   <div>
   <input type="text" name="newsomatic_Main_Settings[pexels_api]" value="<?php
      echo esc_html($pexels_api);
      ?>" placeholder="<?php echo esc_html__("Please insert your Pexels API key");?>">
   </div>
   </td></tr>
   <tr><td colspan="2"><hr class="cr_dotted"/></td></tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo sprintf( wp_kses( __( "Insert your Flickr App ID. Learn how to get an API key <a href='%s' target='_blank'>here</a>. If you enter an API Key and an API Secret, you will enable search for images using the Flickr API."), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( "https://www.flickr.com/services/apps/create/apply" ));
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Flickr App ID: '); ?></b>
   </td>
   <td>
   <input type="text" name="newsomatic_Main_Settings[flickr_api]" placeholder="<?php echo esc_html__("Please insert your Flickr APP ID");?>" value="<?php if(isset($flickr_api)){echo esc_html($flickr_api);}?>" class="cr_width_full" />
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("The license id for photos to be searched.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Photo License: '); ?></b>
   </td>
   <td> 
   <select name="newsomatic_Main_Settings[flickr_license]" class="cr_width_full">
   <option value="-1" 
      <?php
         if($flickr_license == '-1')
         {
             echo ' selected';
         }
         ?>
      ><?php echo esc_html__("Do Not Search By Photo Licenses");?></option>
   <option value="0"
      <?php
         if($flickr_license == '0')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("All Rights Reserved");?></option>
   <option value="1"
      <?php
         if($flickr_license == '1')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Attribution-NonCommercial-ShareAlike License");?></option>
   <option value="2"
      <?php
         if($flickr_license == '2')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Attribution-NonCommercial License");?></option>
   <option value="3"
      <?php
         if($flickr_license == '3')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Attribution-NonCommercial-NoDerivs License");?></option>
   <option value="4"
      <?php
         if($flickr_license == '4')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Attribution License");?></option>
   <option value="5"
      <?php
         if($flickr_license == '5')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Attribution-ShareAlike License");?></option>
   <option value="6"
      <?php
         if($flickr_license == '6')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Attribution-NoDerivs License");?></option>
   <option value="7"
      <?php
         if($flickr_license == '7')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("No known copyright restrictions");?></option>
   <option value="8"
      <?php
         if($flickr_license == '8')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("United States Government Work");?></option>
   </select> 
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("The order in which to sort returned photos. Deafults to date-posted-desc (unless you are doing a radial geo query, in which case the default sorting is by ascending distance from the point specified).");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Search Results Order: '); ?></b>
   </td>
   <td>
   <select name="newsomatic_Main_Settings[flickr_order]" class="cr_width_full">
   <option value="date-posted-desc"
      <?php
         if($flickr_order == 'date-posted-desc')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Date Posted Descendant");?></option>
   <option value="date-posted-asc"
      <?php
         if($flickr_order == 'date-posted-asc')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Date Posted Ascendent");?></option>
   <option value="date-taken-asc"
      <?php
         if($flickr_order == 'date-taken-asc')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Date Taken Ascendent");?></option>
   <option value="date-taken-desc"
      <?php
         if($flickr_order == 'date-taken-desc')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Date Taken Descendant");?></option>
   <option value="interestingness-desc"
      <?php
         if($flickr_order == 'interestingness-desc')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Interestingness Descendant");?></option>
   <option value="interestingness-asc"
      <?php
         if($flickr_order == 'interestingness-asc')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Interestingness Ascendant");?></option>
   <option value="relevance"
      <?php
         if($flickr_order == 'relevance')
         {
             echo ' selected';
         }
         ?>><?php echo esc_html__("Relevance");?></option>
   </select>    
   <tr><td colspan="2"><hr class="cr_dotted"/></td></tr>        
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo sprintf( wp_kses( __( "Insert your Pixabay App ID. Learn how to get one <a href='%s' target='_blank'>here</a>. If you enter an API Key here, you will enable search for images using the Pixabay API."), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( "https://pixabay.com/api/docs/" ) );
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Pixabay App ID:");?></b>
   </div>
   </td><td>
   <div>
   <input type="text" name="newsomatic_Main_Settings[pixabay_api]" value="<?php
      echo esc_html($pixabay_api);
      ?>" placeholder="<?php echo esc_html__("Please insert your Pixabay API key");?>">
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Filter results by image type.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Image Types To Search:");?></b>
   </div>
   </td><td>
   <div>
   <select class="cr_width_full" name="newsomatic_Main_Settings[imgtype]" >
   <option value='all'<?php
      if ($imgtype == 'all')
          echo ' selected';
      ?>><?php echo esc_html__("All");?></option>
   <option value='photo'<?php
      if ($imgtype == 'photo')
          echo ' selected';
      ?>><?php echo esc_html__("Photo");?></option>
   <option value='illustration'<?php
      if ($imgtype == 'illustration')
          echo ' selected';
      ?>><?php echo esc_html__("Illustration");?></option>
   <option value='vector'<?php
      if ($imgtype == 'vector')
          echo ' selected';
      ?>><?php echo esc_html__("Vector");?></option>
   </select>  
   </div>
   </td></tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Order results by a predefined rule.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Results Order: '); ?></b>
   </td>
   <td>
   <select name="newsomatic_Main_Settings[img_order]" class="cr_width_full">
   <option value="popular"<?php
      if ($img_order == "popular") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Popular");?></option>
   <option value="latest"<?php
      if ($img_order == "latest") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Latest");?></option>
   </select>     
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Filter results by image category.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Image Category: '); ?></b>
   </td>
   <td>
   <select name="newsomatic_Main_Settings[img_cat]" class="cr_width_full">
   <option value="all"<?php
      if ($img_cat == "all") {
          echo " selected";
      }
      ?>><?php echo esc_html__("All");?></option>
   <option value="fashion"<?php
      if ($img_cat == "fashion") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Fashion");?></option>
   <option value="nature"<?php
      if ($img_cat == "nature") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Nature");?></option>
   <option value="backgrounds"<?php
      if ($img_cat == "backgrounds") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Backgrounds");?></option>
   <option value="science"<?php
      if ($img_cat == "science") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Science");?></option>
   <option value="education"<?php
      if ($img_cat == "education") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Education");?></option>
   <option value="people"<?php
      if ($img_cat == "people") {
          echo " selected";
      }
      ?>><?php echo esc_html__("People");?></option>
   <option value="feelings"<?php
      if ($img_cat == "feelings") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Feelings");?></option>
   <option value="religion"<?php
      if ($img_cat == "religion") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Religion");?></option>
   <option value="health"<?php
      if ($img_cat == "health") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Health");?></option>
   <option value="places"<?php
      if ($img_cat == "places") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Places");?></option>
   <option value="animals"<?php
      if ($img_cat == "animals") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Animals");?></option>
   <option value="industry"<?php
      if ($img_cat == "industry") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Industry");?></option>
   <option value="food"<?php
      if ($img_cat == "food") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Food");?></option>
   <option value="computer"<?php
      if ($img_cat == "computer") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Computer");?></option>
   <option value="sports"<?php
      if ($img_cat == "sports") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Sports");?></option>
   <option value="transportation"<?php
      if ($img_cat == "transportation") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Transportation");?></option>
   <option value="travel"<?php
      if ($img_cat == "travel") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Travel");?></option>
   <option value="buildings"<?php
      if ($img_cat == "buildings") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Buildings");?></option>
   <option value="business"<?php
      if ($img_cat == "business") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Business");?></option>
   <option value="music"<?php
      if ($img_cat == "music") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Music");?></option>
   </select>    
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Minimum image width.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Image Min Width: '); ?></b>
   </td>
   <td>
   <input type="number" min="1" step="1" name="newsomatic_Main_Settings[img_width]" value="<?php echo esc_html($img_width);?>" placeholder="<?php echo esc_html__("Please insert image min width");?>" class="cr_width_full">     
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Maximum image width.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Image Max Width: '); ?></b>
   </td>
   <td>
   <input type="number" min="1" step="1" name="newsomatic_Main_Settings[img_mwidth]" value="<?php echo esc_html($img_mwidth);?>" placeholder="<?php echo esc_html__("Please insert image max width");?>" class="cr_width_full">     
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("A flag indicating that only images suitable for all ages should be returned.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Safe Search: '); ?></b>
   </td>
   <td>
   <input type="checkbox" name="newsomatic_Main_Settings[img_ss]"<?php
      if ($img_ss == 'on') {
          echo ' checked="checked"';
      }
      ?> >
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Select images that have received an Editor's Choice award.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Editor\'s Choice: '); ?></b>
   </td>
   <td>
   <input type="checkbox" name="newsomatic_Main_Settings[img_editor]"<?php
      if ($img_editor == 'on') {
          echo ' checked="checked"';
      }
      ?> >
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Specify default language for regional content.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Filter Language: '); ?></b>
   </td>
   <td>
   <select name="newsomatic_Main_Settings[img_language]" class="cr_width_full">
   <option value="any"<?php
      if ($img_language == "any") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Any");?></option>
   <option value="en"<?php
      if ($img_language == "en") {
          echo " selected";
      }
      ?>><?php echo esc_html__("English");?></option>
   <option value="cs"<?php
      if ($img_language == "cs") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Czech");?></option>
   <option value="da"<?php
      if ($img_language == "da") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Danish");?></option>
   <option value="de"<?php
      if ($img_language == "de") {
          echo " selected";
      }
      ?>><?php echo esc_html__("German");?></option>
   <option value="es"<?php
      if ($img_language == "es") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Spanish");?></option>
   <option value="fr"<?php
      if ($img_language == "fr") {
          echo " selected";
      }
      ?>><?php echo esc_html__("French");?></option>
   <option value="id"<?php
      if ($img_language == "id") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Indonesian");?></option>
   <option value="it"<?php
      if ($img_language == "it") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Italian");?></option>
   <option value="hu"<?php
      if ($img_language == "hu") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Hungarian");?></option>
   <option value="nl"<?php
      if ($img_language == "nl") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Dutch");?></option>
   <option value="no"<?php
      if ($img_language == "no") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Norvegian");?></option>
   <option value="pl"<?php
      if ($img_language == "pl") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Polish");?></option>
   <option value="pt"<?php
      if ($img_language == "pt") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Portuguese");?></option>
   <option value="ro"<?php
      if ($img_language == "ro") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Romanian");?></option>
   <option value="sk"<?php
      if ($img_language == "sk") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Slovak");?></option>
   <option value="fi"<?php
      if ($img_language == "fi") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Finish");?></option>
   <option value="sv"<?php
      if ($img_language == "sv") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Swedish");?></option>
   <option value="tr"<?php
      if ($img_language == "tr") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Turkish");?></option>
   <option value="vi"<?php
      if ($img_language == "vi") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Vietnamese");?></option>
   <option value="th"<?php
      if ($img_language == "th") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Thai");?></option>
   <option value="bg"<?php
      if ($img_language == "bg") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Bulgarian");?></option>
   <option value="ru"<?php
      if ($img_language == "ru") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Russian");?></option>
   <option value="el"<?php
      if ($img_language == "el") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Greek");?></option>
   <option value="ja"<?php
      if ($img_language == "ja") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Japanese");?></option>
   <option value="ko"<?php
      if ($img_language == "ko") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Korean");?></option>
   <option value="zh"<?php
      if ($img_language == "zh") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Chinese");?></option>
   </select>    
   </td>
   </tr>
   <tr><td colspan="2"><hr class="cr_dotted"/></td></tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Select if you want to enable direct scraping of Pixabay website. This will generate different results from the API.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Enable Pixabay Direct Website Scraping: '); ?></b>
   </td>
   <td>
   <input type="checkbox" name="newsomatic_Main_Settings[pixabay_scrape]"<?php
      if ($pixabay_scrape == 'on') {
          echo ' checked="checked"';
      }
      ?> >
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Filter results by image type.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Image Types To Search: '); ?></b>
   </td>
   <td>
   <select name="newsomatic_Main_Settings[scrapeimgtype]" class="cr_width_full">
   <option value="all"<?php
      if ($scrapeimgtype == "all") {
          echo " selected";
      }
      ?>><?php echo esc_html__("All");?></option>
   <option value="photo"<?php
      if ($scrapeimgtype == "photo") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Photo");?></option>
   <option value="illustration"<?php
      if ($scrapeimgtype == "illustration") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Illustration");?></option>
   <option value="vector"<?php
      if ($scrapeimgtype == "vector") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Vector");?></option>
   </select>     
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Filter results by image orientation.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Image Orientation: '); ?></b>
   </td>
   <td>
   <select name="newsomatic_Main_Settings[scrapeimg_orientation]" class="cr_width_full">
   <option value="all"<?php
      if ($scrapeimg_orientation == "all") {
          echo " selected";
      }
      ?>><?php echo esc_html__("All");?></option>
   <option value="horizontal"<?php
      if ($scrapeimg_orientation == "horizontal") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Horizontal");?></option>
   <option value="vertical"<?php
      if ($scrapeimg_orientation == "vertical") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Vertical");?></option>
   </select>     
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Order results by a predefined rule.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Results Order: '); ?></b>
   </td>
   <td>
   <select name="newsomatic_Main_Settings[scrapeimg_order]" class="cr_width_full">
   <option value="any"<?php
      if ($scrapeimg_order == "any") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Any");?></option>
   <option value="popular"<?php
      if ($scrapeimg_order == "popular") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Popular");?></option>
   <option value="latest"<?php
      if ($scrapeimg_order == "latest") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Latest");?></option>
   </select>     
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Filter results by image category.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Image Category: '); ?></b>
   </td>
   <td>
   <select name="newsomatic_Main_Settings[scrapeimg_cat]" class="cr_width_full">
   <option value="all"<?php
      if ($scrapeimg_cat == "all") {
          echo " selected";
      }
      ?>><?php echo esc_html__("All");?></option>
   <option value="fashion"<?php
      if ($scrapeimg_cat == "fashion") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Fashion");?></option>
   <option value="nature"<?php
      if ($scrapeimg_cat == "nature") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Nature");?></option>
   <option value="backgrounds"<?php
      if ($scrapeimg_cat == "backgrounds") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Backgrounds");?></option>
   <option value="science"<?php
      if ($scrapeimg_cat == "science") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Science");?></option>
   <option value="education"<?php
      if ($scrapeimg_cat == "education") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Education");?></option>
   <option value="people"<?php
      if ($scrapeimg_cat == "people") {
          echo " selected";
      }
      ?>><?php echo esc_html__("People");?></option>
   <option value="feelings"<?php
      if ($scrapeimg_cat == "feelings") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Feelings");?></option>
   <option value="religion"<?php
      if ($scrapeimg_cat == "religion") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Religion");?></option>
   <option value="health"<?php
      if ($scrapeimg_cat == "health") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Health");?></option>
   <option value="places"<?php
      if ($scrapeimg_cat == "places") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Places");?></option>
   <option value="animals"<?php
      if ($scrapeimg_cat == "animals") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Animals");?></option>
   <option value="industry"<?php
      if ($scrapeimg_cat == "industry") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Industry");?></option>
   <option value="food"<?php
      if ($scrapeimg_cat == "food") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Food");?></option>
   <option value="computer"<?php
      if ($scrapeimg_cat == "computer") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Computer");?></option>
   <option value="sports"<?php
      if ($scrapeimg_cat == "sports") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Sports");?></option>
   <option value="transportation"<?php
      if ($scrapeimg_cat == "transportation") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Transportation");?></option>
   <option value="travel"<?php
      if ($scrapeimg_cat == "travel") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Travel");?></option>
   <option value="buildings"<?php
      if ($scrapeimg_cat == "buildings") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Buildings");?></option>
   <option value="business"<?php
      if ($scrapeimg_cat == "business") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Business");?></option>
   <option value="music"<?php
      if ($scrapeimg_cat == "music") {
          echo " selected";
      }
      ?>><?php echo esc_html__("Music");?></option>
   </select>    
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Minimum image width.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Image Min Width: '); ?></b>
   </td>
   <td>
   <input type="number" min="1" step="1" name="newsomatic_Main_Settings[scrapeimg_width]" value="<?php echo esc_html($scrapeimg_width);?>" placeholder="<?php echo esc_html__("Please insert image min width");?>" class="cr_width_full">     
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Maximum image height.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Image Min Height: '); ?></b>
   </td>
   <td>
   <input type="number" min="1" step="1" name="newsomatic_Main_Settings[scrapeimg_height]" value="<?php echo esc_html($scrapeimg_height);?>" placeholder="<?php echo esc_html__("Please insert image min height");?>" class="cr_width_full">     
   </td>
   </tr> 
   <tr><td colspan="2"><hr class="cr_dotted"/></td></tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Please set a the image attribution shortcode value. You can use this value, using the %%image_attribution%% shortcode, in 'Prepend Content With' and 'Append Content With' settings fields. You can use the following shortcodes, in this settings field: %%image_source_name%%, %%image_source_website%%, %%image_source_url%%. These will be updated automatically for the respective image source, from where the imported image is from. This will replace the %%royalty_free_image_attribution%% shortcode, in 'Generated Post Content' settings field.");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Royalty Free Image Attribution Text (%%royalty_free_image_attribution%%): '); ?></b>
   </td>
   <td>
   <input type="text" name="newsomatic_Main_Settings[attr_text]" value="<?php echo esc_html(stripslashes($attr_text));?>" placeholder="<?php echo esc_html__("Please insert image attribution text pattern");?>" class="cr_width_full">     
   </td>
   </tr>              
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do you want to enable broad search for royalty free images?");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Enable broad image search: '); ?></b>
   </td>
   <td>
   <input type="checkbox" name="newsomatic_Main_Settings[bimage]" <?php
      if ($bimage == 'on') {
          echo 'checked="checked"';
      }
      ?> />
   </td>
   </tr>
   <tr>
   <td>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do you want to not use article's original image if no royalty free image found for the post?");
      ?>
   </div>
   </div>
   <b><?php esc_html_e('Do Not Use Original Image If No Free Image Found: '); ?></b>
   </td>
   <td>
   <input type="checkbox" name="newsomatic_Main_Settings[no_orig]" <?php
      if ($no_orig == 'on') {
          echo 'checked="checked"';
      }
      ?> />
   </td>
   </tr>
   <tr><td><hr/></td><td><hr/></td></tr>
<tr><td><div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-default" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings");?>"/></p></div></td><td></td></tr>

 </table>
</div></div></div></div>


<!-- Start row -->
  <div class="row options-listed options-random-sentence-generator">


    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
        Random Sentence Generator Settings
        </div>

            <div class="panel-body">

 <table>
   <tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Insert some sentences from which you want to get one at random. You can also use variables defined below. %something ==> is a variable. Each sentence must be separated by a new line.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("First List of Possible Sentences (%%random_sentence%%):");?></b>
   </td><td>
   <textarea rows="8" cols="70" name="newsomatic_Main_Settings[sentence_list]" placeholder="<?php echo esc_html__("Please insert the first list of sentences");?>"><?php
      echo esc_textarea($sentence_list);
      ?></textarea>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Insert some sentences from which you want to get one at random. You can also use variables defined below. %something ==> is a variable. Each sentence must be separated by a new line.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Second List of Possible Sentences (%%random_sentence2%%):");?></b>
   </td><td>
   <textarea rows="8" cols="70" name="newsomatic_Main_Settings[sentence_list2]" placeholder="<?php echo esc_html__("Please insert the second list of sentences");?>"><?php
      echo esc_textarea($sentence_list2);
      ?></textarea>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Insert some variables you wish to be exchanged for different instances of one sentence. Please format this list as follows:<br/>
      Variablename => Variables (seperated by semicolon)<br/>Example:<br/>adjective => clever;interesting;smart;huge;astonishing;unbelievable;nice;adorable;beautiful;elegant;fancy;glamorous;magnificent;helpful;awesome<br/>");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("List of Possible Variables:");?></b>
   </td><td>
   <textarea rows="8" cols="70" name="newsomatic_Main_Settings[variable_list]" placeholder="<?php echo esc_html__("Please insert the list of variables");?>"><?php
      echo esc_textarea($variable_list);
      ?></textarea>
   </div></td></tr>
   <tr><td>   
   	<div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-default" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings");?>"/></p></div>
</td><td></td></tr>

</table>


</div></div></div></div>








<!-- Start row -->
  <div class="row options-listed options-custom-html-ad-code">


    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
        <?php echo esc_html__("Custom HTML Code/ Ad Code:");?>
        </div>

            <div class="panel-body">

<table>
   <tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Insert a custom HTML code that will replace the %%custom_html%% variable. This can be anything, even an Ad code.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Custom HTML Code #1:");?></b>
   </td><td>
   <textarea rows="3" cols="70" name="newsomatic_Main_Settings[custom_html]" placeholder="<?php echo esc_html__("Custom HTML #1");?>"><?php
      echo esc_textarea($custom_html);
      ?></textarea>
   </div>
   </td></tr><tr><td>
   <div>
   <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Insert a custom HTML code that will replace the %%custom_html2%% variable. This can be anything, even an Ad code.");
      ?>
   </div>
   </div>
   <b><?php echo esc_html__("Custom HTML Code #2:");?></b>
   </td><td>
   <textarea rows="3" cols="70" name="newsomatic_Main_Settings[custom_html2]" placeholder="<?php echo esc_html__("Custom HTML #2");?>"><?php
      echo esc_textarea($custom_html2);
      ?></textarea>
   </div>
   </td></tr>
<tr><td><div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-default" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings");?>"/></p></div></td><td></td></tr></table>
   <hr/>

</table>

</div></div></div></div>




   <div class="options-listed options-affiliate-keyword-replacer">
   <div class="table-responsive">
   <table class="responsive table cr_main_table">
   <thead>
   <tr>
   <th><?php echo esc_html__("ID");?><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("This is the ID of the rule.");
      ?>
   </div>
   </div></th>
   <th class="cr_max_width_40"><?php echo esc_html__("Del");?><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Do you want to delete this rule?");
      ?>
   </div>
   </div></th>
   <th><?php echo esc_html__("Search Keyword");?><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("This keyword will be replaced with a link you define.");
      ?>
   </div>
   </div></th>
   <th><?php echo esc_html__("Replacement Keyword");?><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("This keyword will replace the search keyword you define. Leave this field blank if you only want to add an URL to the specified keyword.");
      ?>
   </div>
   </div></th>
   <th><?php echo esc_html__("Link to Add");?><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Define the link you want to appear the defined keyword. Leave this field blank if you only want to replace the specified keyword without linking from it.");
      ?>
   </div>
   </div></th>
   <th><?php echo esc_html__("Target Content");?><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
   <div class="bws_hidden_help_text cr_min_260px">
   <?php
      echo esc_html__("Select if you want to make this rule target post title, content or both.");
      ?>
   </div>
   </div></th>
   </tr>
   <tr><td><hr/></td><td><hr/></td><td><hr/></td><td><hr/></td><td><hr/></td><td><hr/></td></tr>
   </thead>
   <tbody>
   <?php
      echo newsomatic_expand_keyword_rules();
      ?>
   <tr>
   <td class="cr_short_td">-</td>
   <td class="cr_shrt_td2"><span class="cr_gray20">X</span></td>
   <td class="cr_rule_line"><input type="text" name="newsomatic_keyword_list[keyword][]"  placeholder="<?php echo esc_html__("Please insert the keyword to be replaced");?>" value="" class="cr_width_100" /></td>
   <td class="cr_rule_line"><input type="text" name="newsomatic_keyword_list[replace][]"  placeholder="<?php echo esc_html__("Please insert the keyword to replace the search keyword");?>" value="" class="cr_width_100" /></td>
   <td class="cr_rule_line"><input type="url" validator="url" name="newsomatic_keyword_list[link][]" placeholder="<?php echo esc_html__("Please insert the link to be added to the keyword");?>" value="" class="cr_width_100" /></td>
   <td class="cr_xoq"><select id="newsomatic_keyword_target" name="newsomatic_keyword_list[target][]" class="cr_width_full">
   <option value="content" selected><?php echo esc_html__("Content");?></option>
   <option value="title"><?php echo esc_html__("Title");?></option>
   <option value="both"><?php echo esc_html__("Content and Title");?></option></select></td>
   </tr>
   </tbody>
   </table>
   <hr/>
   <p style="display:none;">
   Available shortcodes (the plugin also provides Gutenberg blocks for these shortcodes): <strong>[newszoo-list-posts]</strong> <?php echo esc_html__("to include a list that contains only posts imported by this plugin, and");?> <strong>[newsomatic-display-posts]</strong> <?php echo esc_html__("to include a WordPress like post listing. Usage:");?> [newszoo-display-posts type='any/post/page/...' title_color='#ffffff' excerpt_color='#ffffff' read_more_text="Read More" link_to_source='yes' order='ASC/DESC' orderby='title/ID/author/name/date/rand/comment_count' title_font_size='19px', excerpt_font_size='19px' posts_per_page=number_of_posts_to_show category='posts_category' ruleid='ID_of_newsomatic_rule' ruletype='0/1'].
   <br/><?php echo esc_html__("Example:");?> <b>[newszoo-list-posts type='any' order='ASC' orderby='date' posts_per_page=50 category= '' ruleid='0' ruletype='0']</b>
   <br/><?php echo esc_html__("Example 2:");?> <b>[newszoo-display-posts include_excerpt='true' image_size='thumbnail' wrapper='div' ruleid='0' ruletype='0']</b>.
   </p>
   <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-default" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings");?>"/></p></div>
   </form>
   </div>
</div>





</div>
<!-- END CONTAINER -->
 <!-- //////////////////////////////////////////////////////////////////////////// --> 


<!-- Start Footer -->
<div class="row footer">
  <div class="col-md-6 text-left">
  Copyright © 2019
  </div>
</div>
<!-- End Footer -->


</div>
<!-- End Content -->
 <!-- //////////////////////////////////////////////////////////////////////////// --> 

</div><!-- end cms -->


<script src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'styles/kode/js/bootstrap/bootstrap.min.js');?>"></script>

<!-- ================================================
Plugin.js - Some Specific JS codes for Plugin Settings
================================================ -->
<script type="text/javascript" src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'styles/kode/js/plugins.js');?>"></script>



<?php
   }
   if (isset($_POST['newsomatic_keyword_list'])) {
       add_action('admin_init', 'newsomatic_save_keyword_rules');
   }
   function newsomatic_save_keyword_rules($data2)
   {
       $data2 = $_POST['newsomatic_keyword_list'];
       $rules = array();
       if (isset($data2['keyword'][0])) {
           for ($i = 0; $i < sizeof($data2['keyword']); ++$i) {
               if (isset($data2['keyword'][$i]) && $data2['keyword'][$i] != '') {
                   $index         = trim(sanitize_text_field($data2['keyword'][$i]));
                   $rules[$index] = array(
                       trim(sanitize_text_field($data2['link'][$i])),
                       trim(sanitize_text_field($data2['replace'][$i])),
                       trim(sanitize_text_field($data2['target'][$i]))
                   );
               }
           }
       }
       update_option('newsomatic_keyword_list', $rules);
   }
   function newsomatic_expand_keyword_rules()
   {
       $rules  = get_option('newsomatic_keyword_list');
       $output = '';
       $cont   = 0;
       if (!empty($rules)) {
           foreach ($rules as $request => $value) {
               $output .= '<tr>
                           <td class="cr_short_td">' . esc_html($cont) . '</td>
                           <td class="cr_shrt_td2"><span class="wpnewsomatic-delete">X</span></td>
                           <td class="cr_rule_line"><input type="text" placeholder="' . esc_html__('Input the keyword to be replaced. This field is required') . '" name="newsomatic_keyword_list[keyword][]" value="' . esc_html($request) . '" required class="cr_width_100"></td>
                           <td class="cr_rule_line"><input type="text" placeholder="' . esc_html__('Input the replacement word') . '" name="newsomatic_keyword_list[replace][]" value="' . esc_html($value[1]) . '" class="cr_width_100"></td>
                           <td class="cr_rule_line"><input type="url" validator="url" placeholder="' . esc_html__('Input the URL to be added') . '" name="newsomatic_keyword_list[link][]" value="' . esc_html($value[0]) . '" class="cr_width_100"></td>';
                           if(isset($value[2]))
                           {
                               $target = $value[2];
                           }
                           else
                           {
                               $target = 'content';
                           }
                           $output .= '<td class="cr_xoq"><select id="newsomatic_keyword_target" name="newsomatic_keyword_list[target][]" class="cr_width_full">
                                     <option value="content"';
                           if ($target == "content") {
                               $output .= " selected";
                           }
                           $output .= '>' . esc_html__('Content') . '</option>
                           <option value="title"';
                           if ($target == "title") {
                               $output .=  " selected";
                           }
                           $output .= '>' . esc_html__('Title') . '</option>
                           <option value="both"';
                           if ($target == "both") {
                               $output .=  " selected";
                           }
                           $output .= '>' . esc_html__('Content and Title') . '</option>
                       </select></td>
            </tr>';
               $cont++;
           }
       }
       return $output;
   }
   ?>