<?php
   function newsomatic_recommendations()
   {
   update_option('xxxxsettings_viewedx', 1);
   ?>


<?php include('newsomatic-mainmenu.php'); ?>



 <!-- //////////////////////////////////////////////////////////////////////////// --> 
<!-- START CONTAINER -->
<div class="container-padding">
         <div>
            <div class="hideMain">

<div class="wrap gs_popuptype_holder seo_pops">
   <div>
      <div>
         <h3>
            <?php echo esc_html__("Our Recommendations");?>: 
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
               <div class="bws_hidden_help_text cr_min_260px">
                  <?php
                     echo esc_html__("Some general recommendations, to help boost the ROI of this plugin and your website.");
                     ?>
               </div>
            </div>
         </h3>
         <hr/>
         <b>
            <ol>
               <li>
                  <h2><?php echo esc_html__("Import premium unique content for more organic traffic:");?></h2>
                  <?php echo esc_html__("To import good quality unique content, we recommend that you use a premium text spinning service with the plugin (can be configured from 'Main Settings' page)");?> - <a href="https://www.youtube.com/watch?v=JuXt8aT-5Jc" target="_blank"><?php echo esc_html__("tutorial video");?></a>. 
                  <br/><?php echo esc_html__("Supported premium spinners:");?><br/><br/>
                  <table class="cr_width_auto">
                     <tr class="cdr-dw-tr">
                        <td class="cdr-dw-td">The Best Spinner&nbsp;&nbsp;&nbsp;&nbsp;</td>
                        <td class="cdr-dw-td-value"><a href="https://coderevolution.jonathanleger.zaxaa.com/s/4152959114554" target="_blank"><?php echo esc_html__("Sign up now");?></a></td>
                     </tr>
                     <tr class="cdr-dw-tr">
                        <td class="cdr-dw-td">SpinRewriter&nbsp;&nbsp;&nbsp;&nbsp;</td>
                        <td class="cdr-dw-td-value"><a href="https://www.spinrewriter.com/?ref=24b18" target="_blank"><?php echo esc_html__("Sign up now");?></a></td>
                     </tr>
                     <tr class="cdr-dw-tr">
                        <td class="cdr-dw-td">WordAI&nbsp;&nbsp;&nbsp;&nbsp;</td>
                        <td class="cdr-dw-td-value"><a href="https://wordai.com/?ref=h17f4" target="_blank"><?php echo esc_html__("Sign up now");?></a></td>
                     </tr>
                  </table>
               </li>
               <li>
                  <h2><?php echo esc_html__("Earn a side income from your blog:");?></h2>
                  <?php echo esc_html__("To earn a side income using our plugins, you can try using");?> <a href="http://join-shortest.com/ref/ff421f2b06?user-type=new" target="_blank"><?php echo esc_html__("Shorte.st link shortener");?></a>. <?php echo esc_html__("It can be configured from plugin's 'Main Settings'");?> - <a href="https://www.youtube.com/watch?v=XFZmzLKddV4" target="_blank"><?php echo esc_html__("tutorial video");?></a>.
               </li>
               <li>
                  <h2><?php echo esc_html__("Create a multilingual blog:");?></h2>
                  <?php echo esc_html__("To create a multilingual blog, we recommend that you use");?> <a href="https://wpml.org/?aid=238195&affiliate_key=ix3LsFyq0xKz" target="_blank">WPML</a>. <?php echo esc_html__("If you just wish to import content in a language, and translate it to another language automatically, our plugins also support Google Translate to achieve this.");?>
               </li>
               <li>
                  <h2><?php echo esc_html__("Like our plugin? Want more?");?></h2>
                  <?php echo esc_html__("Check our");?> <a href="//codecanyon.net/user/coderevolution/portfolio?order_by=sales&ref=coderevolution" target="_blank"><?php echo esc_html__("plugin portfolio from CodeCanyon");?></a>. <?php echo esc_html__("We release periodically new plugins that complement our existing ones, so this list of plugins is worth following. We also have a private plugin marketplace, check it");?> <a href="https://coderevolution.ro/shop/" target="_blank"><?php echo esc_html__("here");?></a>.
               </li>
               <li>
                  <h2><?php echo esc_html__("All our plugins, at a Mega price:");?></h2>
                  <?php echo esc_html__("If you enjoy our work and want to get more of it, check our");?> <a href="//codecanyon.net/item/mega-wordpress-bundle-by-kisded/19200046?ref=coderevolution" target="_blank">Mega 'All-My-Items-Bundle'</a> - <?php echo esc_html__("which is possibly the largest plugin bundle on CodeCanyon. It includes all our plugins (and also all our future plugins), at a 95% discount - so it is really a great deal.");?>
               </li>
               <li>
                  <h2><?php echo esc_html__("Learn more about WordPress (beginners to advanced):");?></h2>
                  <?php echo esc_html__("To learn more about WordPress (or maybe WordPress plugin development), check");?> <a href="https://coderevolution.teachable.com/" target="_blank"><?php echo esc_html__("our online courses on");?> Teachable</a>. <?php echo esc_html__("They provide great value for starters with WordPress, but also for WordPress junior developers. You can also become our");?> <a href="https://teachable.com/affiliates" target="_blank"><?php echo esc_html__("affiliate on Teachable");?></a> <?php echo esc_html__("to earn income from course sales you generate.");?>
               </li>
               <li>
                  <h2><?php echo esc_html__("Learn more about how to create your first internet business (or even earn with it):");?></h2>
                  <?php echo esc_html__("To learn more about how to start your own internet business from scratch, check");?> <a href="https://coderevolution.ro/startup-kit/index.html" target="_blank"><?php echo esc_html__("our e-book on this subject");?></a>. <?php echo esc_html__("You can also become our");?> <a href="https://www.clickbank.com/affiliate-network/" target="_blank"><?php echo esc_html__("affiliate on Clickbank");?></a> <?php echo esc_html__("to earn income from e-book sales you generate.");?>
               </li>
               <li>
                  <h2><?php echo esc_html__("If you are looking for a cool theme:");?></h2>
                  <?php echo esc_html__("If you are looking for a cool new theme that best fits this plugin, we recommend");?> <a href="https://www.elegantthemes.com/affiliates/idevaffiliate.php?id=50837_5_1_16" target="_blank"><?php echo esc_html__("Divi theme");?></a> <?php echo esc_html__("by");?> <a href="https://www.elegantthemes.com/affiliates/idevaffiliate.php?id=50837_1_1_3" target="_blank">ElegantThemes</a>.
               </li>
               <li>
                  <h2><?php echo esc_html__("Earn more by becoming our affiliate:");?></h2>
                  <?php echo esc_html__("You can also become our affiliate (for CodeCanyon items and also for private marketplace items), to earn from the sales you generate for our plugins");?> <a href="https://coderevolution.ro/referral/" target="_blank"><?php echo esc_html__("more info here");?></a>.
               </li>
               <li>
                  <h2><?php echo esc_html__("Check the video tutorials for our plugins:");?></h2>
                  <?php echo esc_html__("For video tutorials, subscribe to our");?> <a href="https://www.youtube.com/channel/UCVLIksvzyk-D_oEdHab2Lgg" target="_blank"><?php echo esc_html__("YouTube channel");?></a> - <?php echo esc_html__("we post periodically new video tutorials over there also.");?>
               </li>
               <li>
                  <h2><?php echo esc_html__("Check our blog and get a free e-book:");?></h2>
                  <?php echo esc_html__("For more updates, tips and tricks follow our");?> <a href="https://coderevolution.ro/" target="_blank"><?php echo esc_html__("blog");?></a> + <?php echo esc_html__("subscribe to our newsletter from our blog, to get our affiliate marketing e-book, for free!");?>
               </li>
               <li>
                  <h2><?php echo esc_html__("Our social networks (for more tips and news):");?></h2>
                  <?php echo esc_html__("Follow us for even more:");?> <a href="//codecanyon.net/user/coderevolution/follow" target="_blank">Envato</a>, <a href="https://www.patreon.com/coderevolution" target="_blank">Patreon</a>, <a href="https://www.facebook.com/CodeRevolution.envato/" target="_blank">Facebook</a>, <a href="https://twitter.com/code2revolution" target="_blank">Twitter</a>, <a href="https://ro.pinterest.com/CodeRevolution2envato/" target="_blank">Pinterest</a>, <a href="https://www.instagram.com/coderevolution_envato/" target="_blank">Instagram</a>, <a href="https://www.linkedin.com/company/coderevolution/" target="_blank">LinkedIn</a>, <a href="https://www.youtube.com/channel/UCVLIksvzyk-D_oEdHab2Lgg" target="_blank">YouTube</a>.
               </li>
            </ol>
         </b>
      </div>
   </div>
</div>

</div>
<!-- END CONTAINER -->
 <!-- //////////////////////////////////////////////////////////////////////////// --> 


<!-- Start Footer -->
<div class="row footer">
  <div class="col-md-6 text-left">
  Copyright © 2019
  </div>
</div>
<!-- End Footer -->


</div>
<!-- End Content -->
 <!-- //////////////////////////////////////////////////////////////////////////// --> 

</div><!-- end cms -->


<script src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'styles/kode/js/bootstrap/bootstrap.min.js');?>"></script>

<!-- ================================================
Plugin.js - Some Specific JS codes for Plugin Settings
================================================ -->
<script type="text/javascript" src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'styles/kode/js/plugins.js');?>"></script>



<?php
   }
   ?>