
<div class="popup-tabs">
    <a id="post-settings" href="#" class="active">Post Settings</a>
    <a id="category-settings" href="#">Category Settings</a>
    <a id="image-settings" href="#">Image Settings</a>
    <a id="content-settings" href="#">Content Settings</a>
</div>