<?php
   function newsomatic_logs()
   {
       global $wp_filesystem;
       if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
           include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
           wp_filesystem($creds);
       }
       if(isset($_POST['newsomatic_delete']))
       {
           if($wp_filesystem->exists(WP_CONTENT_DIR . '/newsomatic_info.log'))
           {
               $wp_filesystem->delete(WP_CONTENT_DIR . '/newsomatic_info.log');
           }
       }
       if(isset($_POST['newsomatic_delete_rules']))
       {
           $running = array();
           update_option('newsomatic_running_list', $running);
       }
       if(isset($_POST['newsomatic_restore_defaults']))
       {
           newsomatic_activation_callback(true);
       }
       if(isset($_POST['newsomatic_delete_all']))
       {
           newsomatic_delete_all_posts();
       }
       if(isset($_POST['newsomatic_refresh_categories']))
       {
           newsomatic_update_categories();
       }
   ?>


<?php include('newsomatic-mainmenu.php'); ?>



 <!-- //////////////////////////////////////////////////////////////////////////// --> 
<!-- START CONTAINER -->
<div class="container-padding">
         <div>
            <div class="hideMain">

<div class="wrap gs_popuptype_holder seo_pops">
   <div>
      <div>
         <h3>
            <?php echo esc_html__("System Info");?>: 
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
               <div class="bws_hidden_help_text cr_min_260px">
                  <?php
                     echo esc_html__("Some general system information.");
                     ?>
               </div>
            </div>
         </h3>
         <hr/>
         <table class="cr_server_stat">
            <tr class="cdr-dw-tr">
               <td class="cdr-dw-td"><?php echo esc_html__("User Agent:");?></td>
               <td class="cdr-dw-td-value"><?php echo $_SERVER['HTTP_USER_AGENT'] ?></td>
            </tr>
            <tr class="cdr-dw-tr">
               <td class="cdr-dw-td"><?php echo esc_html__("Web Server:");?></td>
               <td class="cdr-dw-td-value"><?php echo $_SERVER['SERVER_SOFTWARE'] ?></td>
            </tr>
            <tr class="cdr-dw-tr">
               <td class="cdr-dw-td"><?php echo esc_html__("PHP Version:");?></td>
               <td class="cdr-dw-td-value"><?php echo phpversion(); ?></td>
            </tr>
            <tr class="cdr-dw-tr">
               <td class="cdr-dw-td"><?php echo esc_html__("PHP Max POST Size:");?></td>
               <td class="cdr-dw-td-value"><?php echo ini_get('post_max_size'); ?></td>
            </tr>
            <tr class="cdr-dw-tr">
               <td class="cdr-dw-td"><?php echo esc_html__("PHP Max Upload Size:");?></td>
               <td class="cdr-dw-td-value"><?php echo ini_get('upload_max_filesize'); ?></td>
            </tr>
            <tr class="cdr-dw-tr">
               <td class="cdr-dw-td"><?php echo esc_html__("PHP Memory Limit:");?></td>
               <td class="cdr-dw-td-value"><?php echo ini_get('memory_limit'); ?></td>
            </tr>
            <tr class="cdr-dw-tr">
               <td class="cdr-dw-td"><?php echo esc_html__("PHP DateTime Class:");?></td>
               <td class="cdr-dw-td-value"><?php echo (class_exists('DateTime') && class_exists('DateTimeZone')) ? '<span class="cdr-green">' . esc_html__('Available') . '</span>' : '<span class="cdr-red">' . esc_html__('Not available') . '</span> | <a href="http://php.net/manual/en/datetime.installation.php" target="_blank">more info&raquo;</a>'; ?> </td>
            </tr>
            <tr class="cdr-dw-tr">
               <td class="cdr-dw-td"><?php echo esc_html__("PHP Curl:");?></td>
               <td class="cdr-dw-td-value"><?php echo (function_exists('curl_version')) ? '<span class="cdr-green">' . esc_html__('Available') . '</span>' : '<span class="cdr-red">' . esc_html__('Not available') . '</span>'; ?> </td>
            </tr>
            <?php do_action('coderevolution_dashboard_widget_server') ?>
         </table>
      </div>
      <div>
         <br/>
         <hr class="cr_special_hr"/>
         <div>
            <h3>
               <?php echo esc_html__("Rules Currently Running");?>:
               <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                  <div class="bws_hidden_help_text cr_min_260px">
                     <?php
                        echo esc_html__("These rules are currently running on your server.");
                        ?>
                  </div>
               </div>
            </h3>
            <div>
               <?php
                  if (!get_option('newsomatic_running_list')) {
                      $running = array();
                  } else {
                      $running = get_option('newsomatic_running_list');
                  }
                  if (!empty($running)) {
                      echo '<ul>';
                      foreach($running as $key => $thread)
                      {
                          foreach($thread as $param => $type)
                          {
                              echo '<li><b>' . esc_html($type) . '</b> - ID' . esc_html($param) . '</li>';
                          }
                      }
                      echo '</ul>';        
                  }
                  else
                  {
                      echo esc_html__('No rules are running right now');
                  }
                  ?>
            </div>
            <hr/>
            <form method="post" onsubmit="return confirm('<?php echo esc_html__('Are you sure you want to clear the running list?');?>');">
               <input name="newsomatic_delete_rules" type="submit" title="<?php echo esc_html__('Caution! This is for debugging purpose only!');?>" value="<?php echo esc_html__('Clear Running Rules List');?>">
            </form>
         </div>
         <div class="hideMain">
            <br/>
            <hr class="cr_special_hr"/>
            <div>
               <h3>
                  <?php echo esc_html__("Restore Plugin Default Settings");?>: 
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__('Hit this button and the plugin settings will be restored to their default values. Warning! All settings will be lost!');
                           ?>
                     </div>
                  </div>
               </h3>
               <hr/>
               <form method="post" onsubmit="return confirm('<?php echo esc_html__('Are you sure you want to restore the default plugin settings?');?>');"><input name="newsomatic_restore_defaults" type="submit" value="<?php echo esc_html__('Restore Plugin Default Settings');?>"></form>
            </div>
            <br/>
            <hr class="cr_special_hr"/>
            <div>
               <h3>
                  <?php echo esc_html__("Delete All Posts Generated by this Plugin");?>: 
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__('Hit this button and all posts generated by this plugin will be deleted!');
                           ?>
                     </div>
                  </div>
               </h3>
               <hr/>
               <form method="post" onsubmit="return confirm('<?php echo esc_html__('Are you sure you want to delete all generated posts? This can take a while, please wait until it finishes.');?>');"><input name="newsomatic_delete_all" type="submit" value="<?php echo esc_html__('Delete All Generated Posts');?>"></form>
            </div>
            <br/>
            <hr class="cr_special_hr"/>
            <div>
               <h3>
                  <?php echo esc_html__("Refresh Plugin News Sources");?>: 
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Hit this button you will get the latest news sources published by NewsAPI.");
                           ?>
                     </div>
                  </div>
               </h3>
               <hr/>
               <form method="post" onsubmit="return confirm('Are you sure you want to delete all generated posts? This can take a while, please be patient.');"><input name="newsomatic_refresh_categories" type="submit" value="Refresh News Sources"></form>
            </div>
            <br/>
            <hr class="cr_special_hr"/>
            <h3>
               <?php echo esc_html__("Activity Log");?>:
               <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                  <div class="bws_hidden_help_text cr_min_260px">
                     <?php
                        echo esc_html__('This is the main log of your plugin. Here will be listed every single instance of the rules you run or are automatically run by schedule jobs (if you enable logging, in the plugin configuration).');
                        ?>
                  </div>
               </div>
            </h3>
            <div>
               <?php
                  if($wp_filesystem->exists(WP_CONTENT_DIR . '/newsomatic_info.log'))
                  {
                      $log = $wp_filesystem->get_contents(WP_CONTENT_DIR . '/newsomatic_info.log');
                      echo $log;
                  }
                  else
                  {
                      echo esc_html__("Log empty");
                  }
                  ?>
            </div>
         </div>
         <hr/>
         <form method="post" onsubmit="return confirm('<?php echo esc_html__('Are you sure you want to delete all logs?');?>');">
            <input name="newsomatic_delete" type="submit" value="<?php echo esc_html__('Delete Logs');?>">
         </form>
      </div>
   </div>
</div>


</div>
<!-- END CONTAINER -->
 <!-- //////////////////////////////////////////////////////////////////////////// --> 


<!-- Start Footer -->
<div class="row footer">
  <div class="col-md-6 text-left">
  Copyright © 2019
  </div>
</div>
<!-- End Footer -->


</div>
<!-- End Content -->
 <!-- //////////////////////////////////////////////////////////////////////////// --> 

</div><!-- end cms -->


<script src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'styles/kode/js/bootstrap/bootstrap.min.js');?>"></script>

<!-- ================================================
Plugin.js - Some Specific JS codes for Plugin Settings
================================================ -->
<script type="text/javascript" src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'styles/kode/js/plugins.js');?>"></script>




<?php
   }
   ?>