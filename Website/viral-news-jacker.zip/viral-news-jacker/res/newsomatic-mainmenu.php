<link href="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'styles/kode/css/root.css');?>" rel="stylesheet">

<h1></h1>
<style>
	

.options-listed{
	display:none;
}

.options-listed.options-setup-keys{
	display:block;
}

.panel-body table{
	width:100%;
}

tr > td{
	  padding-bottom: 1em;
}

tr > td b{
	font-weight:300;
	font-size:12px;
}
.cr_status_icon{
	position: absolute;

}

tr.hidethis{
	display:none !important;
}
.popup-tabs{
  border-bottom:1px solid #DDD;
  margin-bottom:30px;
  margin-top:30px;
}
.popup-tabs a{
  display:inline-block;
  border:1px solid #DDD;
  padding:10px 20px;
  margin-bottom:-1px;
  margin-right:-5px;
  text-decoration: none;
  font-size:12px;
  color:#444;
}
.popup-tabs a.active{
  background:#3d464d;
  color:#FFF;
}
.category-settings,
.content-settings,
.image-settings{
  display:none;
}

</style>

<script>
	

jQuery(document).ready(function($) {
	$('body').on('click', 'a.options-setup-keys', function() {
	    $(".options-listed").hide();
	    $('.options-setup-keys').show();
	    $('.sidebar-panel a').removeClass('active');
	    $(this).addClass('active');
	    localStorage.setItem("hash", 'options-setup-keys');
	    //return false;
	});   
	$('body').on('click', 'a.options-plugin-options', function() {
	    $(".options-listed").hide();
	    $('.options-plugin-options').show();
	    $('.sidebar-panel a').removeClass('active');
	    $(this).addClass('active');
	    localStorage.setItem("hash", 'options-plugin-options');
	    //return false;
	});  


	$('body').on('click', 'a.options-post-content-options', function() {
	    $(".options-listed").hide();
	    $('.options-post-content-options').show();
	    $('.sidebar-panel a').removeClass('active');
	    $(this).addClass('active');
	    localStorage.setItem("hash", 'options-post-content-options');
	    //return false;
	});  

	$('body').on('click', 'a.options-post-restrictions', function() {
	    $(".options-listed").hide();
	    $('.options-post-restrictions').show();
	    $('.sidebar-panel a').removeClass('active');
	    $(this).addClass('active');
	    localStorage.setItem("hash", 'options-post-restrictions');
	    //return false;
	});  



	$('body').on('click', 'a.options-featured-image-options', function() {
	    $(".options-listed").hide();
	    $('.options-featured-image-options').show();
	    $('.sidebar-panel a').removeClass('active');
	    $(this).addClass('active');
	    localStorage.setItem("hash", 'options-featured-image-options');
	    //return false;
	});  

	$('body').on('click', 'a.options-royalty-free-featured-image-importing', function() {
	    $(".options-listed").hide();
	    $('.options-royalty-free-featured-image-importing').show();
	    $('.sidebar-panel a').removeClass('active');
	    $(this).addClass('active');
	    localStorage.setItem("hash", 'options-royalty-free-featured-image-importing');
	    //return false;
	});  

	$('body').on('click', 'a.options-random-sentence-generator', function() {
	    $(".options-listed").hide();
	    $('.options-random-sentence-generator').show();
	    $('.sidebar-panel a').removeClass('active');
	    $(this).addClass('active');
	    localStorage.setItem("hash", 'options-random-sentence-generator');	    
	    //return false;
	});  


	$('body').on('click', 'a.options-custom-html-ad-code', function() {
	    $(".options-listed").hide();
	    $('.options-custom-html-ad-code').show();
	    $('.sidebar-panel a').removeClass('active');
	    $(this).addClass('active');
	    localStorage.setItem("hash", 'options-custom-html-ad-code');	    
	    //return false;
	});  

	$('body').on('click', 'a.options-affiliate-keyword-replacer', function() {
	    $(".options-listed").hide();
	    $('.options-affiliate-keyword-replacer').show();
	    $('.sidebar-panel a').removeClass('active');
	    $(this).addClass('active');
	    localStorage.setItem("hash", 'options-affiliate-keyword-replacer');
	    //return false;
	});  


	var hash = window.location.hash.replace('#', '');
	if(hash == '') hash = localStorage.getItem("hash"); 
	//console.log(hash);
    if (hash) {
       	$(".options-listed").hide();
	    $('.' + hash).show();
	    $('.sidebar-panel a').removeClass('active');
	    $('a.' + hash).addClass('active');
		localStorage.setItem("hash", hash);
    }


    <?php if($_GET['page'] == 'newszoo_all_panel') : ?>
	    $('.sidebar-panel a').removeClass('active');
	    $('.rules-all-panel').addClass('active');
    <?php endif; ?>
    
    <?php if($_GET['page'] == 'wpw-auto-poster-settings') : ?>
      $('.sidebar-panel a').removeClass('active');
      $('.options-autoposting-settings').addClass('active');
    <?php endif; ?>

      // $('body').on("click", ".cr_width_70 input", function() {
      //     $(".post-settings").show(); 
      //     $(".category-settings").hide(); 
      //     $(".image-settings").hide(); 
      //     $(".content-settings").hide(); 
      //     $('.popup-tabs a').removeClass('active');
      //     $('#post-settings').addClass('active');
      //     return false;
      // });   

      $('body').on('click', '#post-settings', function() {
          $(".post-settings").show(); 
          $(".category-settings").hide(); 
          $(".image-settings").hide(); 
          $(".content-settings").hide(); 
          $('.popup-tabs a').removeClass('active');
          $(this).addClass('active');
          return false;
      });   

      $('body').on('click', '#category-settings', function() {
          $(".category-settings").show(); 
          $(".post-settings").hide(); 
          $(".image-settings").hide(); 
          $(".content-settings").hide(); 
          $('.popup-tabs a').removeClass('active');
          $(this).addClass('active');
          return false;
      });


      $('body').on('click', '#image-settings', function() {
          $(".image-settings").show(); 
          $(".post-settings").hide(); 
          $(".category-settings").hide(); 
          $(".content-settings").hide(); 
          $('.popup-tabs a').removeClass('active');
          $(this).addClass('active');
          return false;
      });

      $('body').on('click', '#content-settings', function() {
          $(".content-settings").show(); 
          $(".post-settings").hide(); 
          $(".category-settings").hide(); 
          $(".image-settings").hide(); 
          $('.popup-tabs a').removeClass('active');
          $(this).addClass('active');
          return false;
      });


});
</script>

<div class="start-cms">
<!-- //////////////////////////////////////////////////////////////////////////// --> 
<!-- START SIDEBAR -->
<div class="sidebar clearfix">



<ul class="sidebar-panel nav">
  <li style="display:none;"><a href="admin.php?page=newszoo_items_panel"><span class="icon color14"><i class="fa fa-newspaper-o"></i></span>Latest News to Posts</a></li>
  <li><a class="rules-all-panel" href="admin.php?page=newszoo_all_panel"><span class="icon color14"><i class="fa fa-newspaper-o"></i></span>Your Campaigns</a></li>
  <li><a class="options-autoposting-settings" href="admin.php?page=wpw-auto-poster-settings"><span class="icon color12"><i class="fa fa-bullhorn"></i></span>Social Autoposting</a></li>
  <li style="display:none;"><a href="admin.php?page=newszoo_helper"><span class="icon color14"><i class="fa fa-paper-plane-o"></i></span>Crawling Helper</a></li>
  <li style="display:none;"><a href="admin.php?page=newszoo_recommendations"><span class="icon color14"><i class="fa fa-info-circle"></i></span>Tips and Tricks</a></li>
  <li style="display:none;"><a href="admin.php?page=newszoo_logs"><span class="icon color14"><i class="fa fa-leaf"></i></span>Activity & Logging</a></li>
</ul>
<ul class="sidebar-panel nav">
  <li class="sidetitle">VIRAL NEWS JACKER SETTINGS</li>
</ul>
<ul class="sidebar-panel nav">
  <li><a class="active options-setup-keys" href="admin.php?page=newszoo_admin_settings#options-setup-keys"><span class="icon color5"><i class="fa fa-home"></i></span>Setup Keys</a></li>
  <li style="display:none;"><a class="options-plugin-options" href="admin.php?page=newszoo_admin_settings#options-plugin-options"><span class="icon color6"><i class="fa fa-cog"></i></span>Plugin Options</a></li>
  <li><a class="options-post-content-options" href="admin.php?page=newszoo_admin_settings#options-post-content-options"><span class="icon color7"><i class="fa fa-flask"></i></span>Post Content Options</a></li>
  <li><a class="options-post-restrictions" href="admin.php?page=newszoo_admin_settings#options-post-restrictions"><span class="icon color8"><i class="fa fa-eye-slash"></i></span>Posting Restrictions</a></li>
  <li><a class="options-featured-image-options" href="admin.php?page=newszoo_admin_settings#options-featured-image-options"><span class="icon color9"><i class="fa fa-th"></i></span>Featured Image Options</a></li>
  <li><a class="options-royalty-free-featured-image-importing" href="admin.php?page=newszoo_admin_settings#options-royalty-free-featured-image-importing"><span class="icon color10"><i class="fa fa-check-square-o"></i></span>Royalty Free Featured Image Importing Options</a></li>
  <li style="display:none;"><a class="options-random-sentence-generator" href="admin.php?page=newszoo_admin_settings#options-random-sentence-generator"><span class="icon color11"><i class="fa fa-diamond"></i></span>Random Sentence Generator</a></li>
  <li><a class="options-custom-html-ad-code" href="admin.php?page=newszoo_admin_settings#options-custom-html-ad-code"><span class="icon color8"><i class="fa fa-code"></i></span>Custom HTML/Ad Code</a></li>
  <li><a class="options-affiliate-keyword-replacer" href="admin.php?page=newszoo_admin_settings#options-affiliate-keyword-replacer"><span class="icon color12"><i class="fa fa-font"></i></span>Affiliate Keyword Replacer</a></li>
</ul>




</div>
<!-- END SIDEBAR -->
<!-- //////////////////////////////////////////////////////////////////////////// --> 

 <!-- //////////////////////////////////////////////////////////////////////////// --> 
<!-- START CONTENT -->
<div class="content">


  <!-- Start Presentation -->
  <div class="row presentation" style="padding:20px 50px 30px">

    <div class="col-lg-8 col-md-6 titles">
      <h1 style="margin:0">Viral News Jacker</h1>
      <?php if($_GET['page'] == 'newszoo_admin_settings') : ?>
                        <div class="slideThree">  
                           <input class="input-checkbox" type="checkbox" id="newsomatic_enabled" name="newsomatic_Main_Settings[newsomatic_enabled]" onChange="mainChanged()"<?php
                              if ($newsomatic_enabled == 'on')
                                  echo ' checked ';
                              ?>>
                           <label for="newsomatic_enabled"></label>
                        </div>

        <?php endif; ?>

    </div>


  </div>
  <!-- End Presentation -->

<?php

function includeRuleTabs($file){
    ob_start();
    require($file);
    return ob_get_clean();
}
?>